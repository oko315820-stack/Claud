import { i as __toESM } from "../_runtime.mjs";
import { d as require_react_dom, q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as ChevronDown, C as Gift, D as Clock, E as Coffee, M as Bike, N as Bell, O as ChevronRight, P as BadgePercent, S as GlassWater, T as Croissant, _ as MapPin, a as Ticket, b as House, c as Sparkles, d as Plus, f as Phone, g as MessageCircle, h as MessageSquare, i as Trash2, j as Check, k as ChevronLeft, l as ShoppingBag, m as Minus, n as User, o as Sun, p as Moon, s as Star, t as X, u as Search, v as LocateFixed, w as CupSoda, x as Heart, y as Layers } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BZWSI-qm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = require_react_dom();
var toastTimer = 0;
var useUi = create((set, get) => ({
	stack: [{ kind: "splash" }],
	toast: null,
	push: (screen) => set({ stack: [...get().stack, screen] }),
	back: () => {
		const stack = get().stack;
		if (stack.length < 2) return;
		set({ stack: stack.slice(0, -1) });
	},
	reset: (screen) => set({ stack: [screen] }),
	showToast: (text) => {
		set({ toast: text });
		window.clearTimeout(toastTimer);
		toastTimer = window.setTimeout(() => set({ toast: null }), 2200);
	}
}));
var useClock = create(() => ({ now: Date.now() }));
function useScreen() {
	return useUi((state) => state.stack[state.stack.length - 1] ?? { kind: "home" });
}
function screenKey(screen) {
	if (screen.kind === "product") return `product-${screen.productId}`;
	if (screen.kind === "catalog") return `catalog-${screen.mode}`;
	if (screen.kind === "order") return `order-${screen.orderId}`;
	if (screen.kind === "map") return `map-${screen.orderId ?? "cafes"}`;
	return screen.kind;
}
var ADDONS = [
	{
		id: "shot",
		name: "Доп. эспрессо",
		price: 20
	},
	{
		id: "vanilla",
		name: "Ванильный сироп",
		price: 15
	},
	{
		id: "caramel",
		name: "Карамельный сироп",
		price: 15
	},
	{
		id: "oat",
		name: "Овсяное молоко",
		price: 25
	}
];
var PRODUCTS = [
	{
		id: "espresso",
		name: "Эспрессо",
		category: "coffee",
		desc: "Короткий и плотный, с ореховой горчинкой. Двойной — если попросить в комментарии.",
		volume: "100 мл",
		price: 100,
		image: "/menu/espresso.jpg",
		rating: 4.8,
		reviews: 86,
		tags: ["classic"]
	},
	{
		id: "americano",
		name: "Американо",
		category: "coffee",
		desc: "Эспрессо и горячая вода. Чистый вкус зерна, без молока и лишней сладости.",
		volume: "200 мл",
		price: 110,
		image: "/menu/americano.jpg",
		rating: 4.7,
		reviews: 142,
		tags: ["classic"],
		popular: true
	},
	{
		id: "cappuccino",
		name: "Капучино",
		category: "coffee",
		desc: "Равные доли эспрессо, молока и пены. Утренний стандарт нашей смены.",
		volume: "250 мл",
		price: 120,
		image: "/menu/cappuccino.jpg",
		rating: 4.9,
		reviews: 310,
		tags: ["classic"],
		popular: true
	},
	{
		id: "latte",
		name: "Латте",
		category: "coffee",
		desc: "Мягкий эспрессо с молоком и тонкой пенкой. Классика, которую пьют весь день.",
		volume: "300 мл",
		price: 140,
		image: "/menu/latte.jpg",
		rating: 4.8,
		reviews: 124,
		tags: ["classic"],
		popular: true
	},
	{
		id: "flatwhite",
		name: "Флэт уайт",
		category: "coffee",
		desc: "Двойной эспрессо и бархатистое молоко. Меньше пены — больше кофе.",
		volume: "250 мл",
		price: 150,
		image: "/menu/flatwhite.jpg",
		rating: 4.8,
		reviews: 97,
		tags: ["signature"]
	},
	{
		id: "raf",
		name: "Раф ванильный",
		category: "coffee",
		desc: "Сливки, ваниль и эспрессо, взбитые вместе. Сладкий, но не приторный.",
		volume: "300 мл",
		price: 160,
		image: "/menu/raf.jpg",
		rating: 4.9,
		reviews: 188,
		tags: ["signature"],
		popular: true
	},
	{
		id: "iced",
		name: "Айс латте",
		category: "coffee",
		desc: "Холодное молоко, лёд и двойной шот. Для жары в Бишкеке и долгой прогулки.",
		volume: "350 мл",
		price: 170,
		image: "/menu/iced.jpg",
		rating: 4.7,
		reviews: 76,
		tags: ["cold"],
		popular: true
	},
	{
		id: "matcha",
		name: "Матча латте",
		category: "coffee",
		desc: "Японская матча и тёплое молоко. Ровная, травяная, без горечи.",
		volume: "300 мл",
		price: 180,
		image: "/menu/matcha.jpg",
		rating: 4.6,
		reviews: 64,
		tags: ["signature"]
	},
	{
		id: "croissant",
		name: "Круассан",
		category: "bakery",
		desc: "Слоёное масло: хруст снаружи и тёплое тесто внутри. Печём утром.",
		volume: "1 шт",
		price: 90,
		image: "/menu/croissant.jpg",
		rating: 4.8,
		reviews: 151,
		tags: [],
		popular: true
	},
	{
		id: "combo-morning",
		name: "Утренний набор",
		category: "combo",
		desc: "Американо и круассан в одном пакете. Дешевле, чем по отдельности.",
		volume: "напиток + выпечка",
		price: 180,
		image: "/menu/croissant.jpg",
		rating: 4.9,
		reviews: 54,
		tags: ["classic"]
	},
	{
		id: "combo-sweet",
		name: "Сладкая пауза",
		category: "combo",
		desc: "Ванильный раф и круассан. Когда хочется и кофе, и десерт.",
		volume: "напиток + выпечка",
		price: 220,
		image: "/menu/raf.jpg",
		rating: 4.8,
		reviews: 41,
		tags: ["signature"]
	}
];
var CAFES = [{
	id: "chuy",
	name: "Зерно на Чуй",
	address: "пр. Чуй, 114",
	hours: "07:00–23:00",
	lat: 42.8765,
	lng: 74.605,
	km: "1,2 км"
}, {
	id: "manas",
	name: "Зерно Азия Молл",
	address: "пр. Манаса, 55",
	hours: "10:00–22:00",
	lat: 42.8558,
	lng: 74.5842,
	km: "3,4 км"
}];
var CAFE = CAFES[0];
var DEFAULT_ADDRESSES = [{
	id: "home",
	label: "Дом",
	text: "ул. Манаса, 12, кв. 45",
	lat: 42.866,
	lng: 74.586
}, {
	id: "office",
	label: "Офис",
	text: "ул. Киевская, 77",
	lat: 42.8751,
	lng: 74.5888
}];
var CITIES = [
	"Бишкек",
	"Ош",
	"Каракол"
];
var ETAS = [
	"Как можно скорее",
	"30–45 мин",
	"45–60 мин",
	"Через час"
];
var PAYMENTS = [
	{
		id: "card",
		name: "Картой онлайн"
	},
	{
		id: "cash",
		name: "Наличными курьеру"
	},
	{
		id: "phone",
		name: "Телефоном"
	}
];
var FAQ = [
	{
		q: "Сколько едет курьер?",
		a: "По Бишкеку обычно 20–40 минут. После оплаты на карте видно, где он сейчас."
	},
	{
		q: "Можно без сиропа или льда?",
		a: "Да. Напишите в комментарии к заказу — бариста увидит до того, как начнёт готовить."
	},
	{
		q: "Как работают баллы?",
		a: "5% с каждого заказа возвращаются баллами. На оплате можно списать до 30% чека. 500 баллов — капучино."
	},
	{
		q: "Какие промокоды есть?",
		a: "ZERNO20 снимает 20% с корзины. SWEET50 снимает 50 с. Вводится в корзине."
	}
];
function productById(id) {
	return PRODUCTS.find((item) => item.id === id);
}
function addonById(id) {
	return ADDONS.find((item) => item.id === id);
}
function unitPrice(productId, addonIds) {
	const product = productById(productId);
	if (!product) return 0;
	const extra = addonIds.reduce((sum, id) => sum + (addonById(id)?.price ?? 0), 0);
	return product.price + extra;
}
function productsFor(mode) {
	return PRODUCTS.filter((item) => {
		if (mode === "all") return true;
		if (mode === "popular") return Boolean(item.popular);
		if (mode === "coffee") return item.category === "coffee";
		if (mode === "bakery") return item.category === "bakery";
		if (mode === "combo") return item.category === "combo";
		if (mode === "cold") return item.tags.includes("cold");
		if (mode === "signature") return item.tags.includes("signature");
		if (mode === "classic") return item.tags.includes("classic");
		return true;
	});
}
function promoDiscount(code, subtotal) {
	if (!code || subtotal <= 0) return 0;
	if (code === "ZERNO20") return Math.round(subtotal * .2);
	if (code === "SWEET50") return Math.min(50, subtotal);
	return 0;
}
function som(value) {
	return `${Math.round(value)} с`;
}
function itemsLabel(count) {
	const mod10 = count % 10;
	const mod100 = count % 100;
	if (mod10 === 1 && mod100 !== 11) return `${count} товар`;
	if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${count} товара`;
	return `${count} товаров`;
}
function clock(ts) {
	return new Intl.DateTimeFormat("ru-RU", {
		hour: "2-digit",
		minute: "2-digit"
	}).format(ts);
}
function dayTime(ts) {
	return new Intl.DateTimeFormat("ru-RU", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}).format(ts);
}
var STATUS_FLOW = [
	"accepted",
	"cooking",
	"enroute",
	"delivered"
];
var STAGE_MS = {
	accepted: 6e3,
	cooking: 7e3,
	enroute: 22e3,
	delivered: Number.POSITIVE_INFINITY
};
var STATUS_COPY = {
	accepted: ["Заказ принят", "Кухня уже видит ваш заказ."],
	cooking: ["Готовится", "Бариста собирает напитки."],
	enroute: ["Курьер в пути", "Тимур выехал. Можно открыть карту."],
	delivered: ["Заказ доставлен", "Приятного кофе. Спасибо, что выбрали Зерно."]
};
function lineKey(productId, addonIds, gift = false) {
	const addons = [...addonIds].sort().join(",");
	return gift ? `${productId}:gift` : `${productId}:${addons}`;
}
function seedNow() {
	return Date.now();
}
function makeNote(partial) {
	return {
		read: false,
		id: `n-${partial.at}-${partial.title}`,
		...partial
	};
}
var openedAt = seedNow();
function seedOrders() {
	const latte = productById("latte");
	const cap = productById("cappuccino");
	const croissant = productById("croissant");
	const iced = productById("iced");
	if (!latte || !cap || !croissant || !iced) return [];
	const home = DEFAULT_ADDRESSES[0];
	const older = openedAt - 936e5;
	const newer = openedAt - 18e6;
	return [{
		id: "45871",
		createdAt: newer,
		lines: [{
			productId: cap.id,
			name: cap.name,
			qty: 1,
			unit: cap.price,
			image: cap.image
		}, {
			productId: croissant.id,
			name: croissant.name,
			qty: 1,
			unit: croissant.price,
			image: croissant.image
		}],
		total: 210,
		address: home.text,
		lat: home.lat,
		lng: home.lng,
		mode: "delivery",
		payment: "Картой онлайн",
		comment: "",
		eta: "30–45 мин",
		status: "delivered",
		history: STATUS_FLOW.map((status, index) => ({
			status,
			at: newer + index * 6e4
		}))
	}, {
		id: "45862",
		createdAt: older,
		lines: [{
			productId: latte.id,
			name: latte.name,
			qty: 2,
			unit: latte.price,
			image: latte.image
		}, {
			productId: iced.id,
			name: iced.name,
			qty: 1,
			unit: iced.price,
			image: iced.image
		}],
		total: 450,
		address: "Самовывоз · пр. Чуй, 114",
		lat: CAFE.lat,
		lng: CAFE.lng,
		mode: "pickup",
		payment: "Наличными курьеру",
		comment: "Без сиропа",
		eta: "15 мин",
		status: "delivered",
		history: STATUS_FLOW.map((status, index) => ({
			status,
			at: older + index * 6e4
		}))
	}];
}
function cartUnit(line) {
	if (typeof line.priceOverride === "number") return line.priceOverride;
	return unitPrice(line.productId, line.addonIds);
}
function cartCount(cart) {
	return cart.reduce((sum, line) => sum + line.qty, 0);
}
function cartSubtotal(cart) {
	return cart.reduce((sum, line) => sum + cartUnit(line) * line.qty, 0);
}
var useApp = create()(persist((set, get) => ({
	entered: false,
	theme: "light",
	city: "Бишкек",
	cart: [],
	promo: null,
	favorites: ["latte", "raf"],
	orders: seedOrders(),
	bonuses: 320,
	profile: {
		name: "Нурлан Асанов",
		phone: "+996 555 120 334",
		email: "nurlan@zerno.kg"
	},
	addresses: DEFAULT_ADDRESSES,
	addressId: "home",
	payment: "card",
	notes: [
		makeNote({
			title: "Скидка 20% на кофе",
			body: "Промокод ZERNO20 действует сегодня на всю корзину.",
			at: openedAt - 3e6,
			tone: "promo"
		}),
		makeNote({
			title: "Новое в меню",
			body: "Ванильный раф и матча латте уже можно заказать.",
			at: openedAt - 936e5,
			tone: "info",
			read: true
		}),
		makeNote({
			title: "На счёте 320 баллов",
			body: "До капучино в подарок осталось 180. Копите или списывайте на оплате.",
			at: openedAt - 2592e5,
			tone: "bonus",
			read: true
		})
	],
	support: [{
		id: "s0",
		from: "them",
		text: "Здравствуйте. Это Зерно. Напишите, если заказ задерживается или напиток приехал не таким.",
		at: openedAt - 6e4
	}],
	courierChat: [],
	enter: () => set({ entered: true }),
	setTheme: (theme) => set({ theme }),
	toggleTheme: () => set({ theme: get().theme === "dark" ? "light" : "dark" }),
	setCity: (city) => set({ city }),
	toggleFavorite: (productId) => set({ favorites: get().favorites.includes(productId) ? get().favorites.filter((id) => id !== productId) : [...get().favorites, productId] }),
	addToCart: (productId, addonIds, qty = 1, priceOverride) => {
		const key = lineKey(productId, addonIds, typeof priceOverride === "number");
		const cart = get().cart;
		if (cart.find((line) => line.key === key)) {
			set({ cart: cart.map((line) => line.key === key ? {
				...line,
				qty: line.qty + qty
			} : line) });
			return;
		}
		set({ cart: [...cart, {
			key,
			productId,
			qty,
			addonIds,
			priceOverride
		}] });
	},
	setQty: (key, qty) => set({ cart: qty <= 0 ? get().cart.filter((line) => line.key !== key) : get().cart.map((line) => line.key === key ? {
		...line,
		qty
	} : line) }),
	clearCart: () => set({
		cart: [],
		promo: null
	}),
	applyPromo: (code) => {
		const normalized = code.trim().toUpperCase();
		if (normalized !== "ZERNO20" && normalized !== "SWEET50") return false;
		set({ promo: normalized });
		return true;
	},
	clearPromo: () => set({ promo: null }),
	setAddress: (id) => set({ addressId: id }),
	addAddress: (text) => {
		const clean = text.trim();
		if (!clean) return;
		const id = `addr-${Date.now()}`;
		const shift = get().addresses.length * .0015;
		const next = {
			id,
			label: "Адрес",
			text: clean,
			lat: 42.87 + shift,
			lng: 74.59 + shift
		};
		set({
			addresses: [...get().addresses, next],
			addressId: id
		});
	},
	setPayment: (id) => set({ payment: id }),
	updateProfile: (profile) => set({ profile }),
	placeOrder: ({ mode, eta, comment, bonusSpend, total }) => {
		const state = get();
		if (state.cart.length === 0) return null;
		const address = mode === "pickup" ? state.addresses.find((item) => item.id === state.addressId) ?? state.addresses[0] : state.addresses.find((item) => item.id === state.addressId) ?? state.addresses[0];
		const point = mode === "pickup" ? {
			text: `Самовывоз · ${CAFE.address}`,
			lat: CAFE.lat,
			lng: CAFE.lng
		} : address;
		const now = Date.now();
		const id = String(46e3 + Math.floor(Math.random() * 3e3));
		const lines = state.cart.map((line) => {
			const product = productById(line.productId);
			return {
				productId: line.productId,
				name: product?.name ?? "Позиция",
				qty: line.qty,
				unit: cartUnit(line),
				image: product?.image ?? "/menu/latte.jpg"
			};
		});
		const paymentName = state.payment === "card" ? "Картой онлайн" : state.payment === "cash" ? "Наличными курьеру" : "Телефоном";
		const order = {
			id,
			createdAt: now,
			lines,
			total,
			address: point.text,
			lat: point.lat,
			lng: point.lng,
			mode,
			payment: paymentName,
			comment: comment.trim(),
			eta,
			status: "accepted",
			history: [{
				status: "accepted",
				at: now
			}]
		};
		const earned = Math.round(total * .05);
		const [title, body] = STATUS_COPY.accepted;
		set({
			orders: [order, ...state.orders].slice(0, 30),
			cart: [],
			promo: null,
			bonuses: Math.max(0, state.bonuses - bonusSpend) + earned,
			notes: [{
				id: `n-${id}-accepted`,
				title,
				body: `Заказ #${id}. ${body}`,
				at: now,
				read: false,
				tone: "order"
			}, ...state.notes]
		});
		return id;
	},
	advanceOrders: (now) => {
		const state = get();
		let changed = false;
		const extraNotes = [];
		const orders = state.orders.map((order) => {
			if (order.status === "delivered") return order;
			let status = order.status;
			let history = order.history;
			let cursor = history[history.length - 1]?.at ?? order.createdAt;
			let moved = false;
			while (status !== "delivered" && now - cursor >= STAGE_MS[status]) {
				const index = STATUS_FLOW.indexOf(status);
				const next = STATUS_FLOW[Math.min(STATUS_FLOW.length - 1, index + 1)];
				cursor += STAGE_MS[status];
				status = next;
				history = [...history, {
					status,
					at: cursor
				}];
				const [title, body] = STATUS_COPY[status];
				extraNotes.push({
					id: `n-${order.id}-${status}`,
					title,
					body: `Заказ #${order.id}. ${body}`,
					at: cursor,
					read: false,
					tone: "order"
				});
				moved = true;
				changed = true;
			}
			return moved ? {
				...order,
				status,
				history
			} : order;
		});
		if (!changed) return;
		set({
			orders,
			notes: [...extraNotes, ...state.notes].slice(0, 40)
		});
	},
	markNotesRead: () => set({ notes: get().notes.map((note) => ({
		...note,
		read: true
	})) }),
	sendSupport: (text) => {
		const clean = text.trim();
		if (!clean) return;
		const now = Date.now();
		const mine = {
			id: `m-${now}`,
			from: "me",
			text: clean,
			at: now
		};
		const reply = {
			id: `r-${now}`,
			from: "them",
			text: "Приняли. Если это про текущий заказ — курьер тоже видит комментарий. Ответим здесь.",
			at: now + 1
		};
		set({ support: [
			...get().support,
			mine,
			reply
		] });
	},
	sendCourier: (text) => {
		const clean = text.trim();
		if (!clean) return;
		const now = Date.now();
		const lower = clean.toLowerCase();
		let answer = "На связи. Если подъезд закрыт — напишите код, я отмечу.";
		if (lower.includes("где") || lower.includes("скоро")) answer = "Еду к вам. На карте красная метка — это я, не кафе.";
		else if (lower.includes("код") || lower.includes("домофон")) answer = "Код записал. Поднимусь и напишу, когда буду у двери.";
		const mine = {
			id: `c-${now}`,
			from: "me",
			text: clean,
			at: now
		};
		const reply = {
			id: `k-${now}`,
			from: "them",
			text: answer,
			at: now + 1
		};
		set({ courierChat: [
			...get().courierChat,
			mine,
			reply
		] });
	},
	claimGift: () => {
		if (get().bonuses < 500) return false;
		set({ bonuses: get().bonuses - 500 });
		get().addToCart("cappuccino", [], 1, 0);
		return true;
	},
	repeatOrder: (orderId) => {
		const order = get().orders.find((item) => item.id === orderId);
		if (!order) return;
		order.lines.forEach((line) => {
			get().addToCart(line.productId, [], line.qty, line.unit === 0 ? 0 : void 0);
		});
	}
}), {
	name: "zerno-app",
	skipHydration: true
}));
function courierPoint(order, now) {
	const dest = {
		lat: order.lat,
		lng: order.lng
	};
	const start = {
		lat: CAFE.lat,
		lng: CAFE.lng
	};
	if (order.mode === "pickup") return start;
	if (order.status === "accepted" || order.status === "cooking") return start;
	if (order.status === "delivered") return dest;
	const began = order.history.find((step) => step.status === "enroute")?.at ?? order.createdAt;
	const raw = Math.min(1, Math.max(0, (now - began) / STAGE_MS.enroute));
	const mid = {
		lat: (start.lat + dest.lat) / 2 + .002,
		lng: (start.lng + dest.lng) / 2 - .002
	};
	const lerp = (a, b, t) => ({
		lat: a.lat + (b.lat - a.lat) * t,
		lng: a.lng + (b.lng - a.lng) * t
	});
	if (raw < .5) return lerp(start, mid, raw / .5);
	return lerp(mid, dest, (raw - .5) / .5);
}
function etaLeft(order, now) {
	if (order.status === "delivered") return "Доставлен";
	if (order.status === "accepted") return "Принят";
	if (order.status === "cooking") return "Готовится";
	if (order.mode === "pickup") return "Можно забирать";
	const began = order.history.find((step) => step.status === "enroute")?.at ?? now;
	const raw = Math.min(1, Math.max(0, (now - began) / STAGE_MS.enroute));
	return `${Math.max(1, Math.round(24 * (1 - raw)))} мин`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function BeanMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "size-5",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
			cx: "12",
			cy: "12",
			rx: "5.5",
			ry: "8.5",
			fill: "currentColor"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 5c1.1 2.2 1.1 4.4 0 14",
			fill: "none",
			stroke: "var(--color-primary)",
			strokeWidth: "1.4",
			strokeLinecap: "round"
		})]
	});
}
function Wordmark({ light = false, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-2", light ? "text-cream" : "text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-9 shrink-0 place-items-center rounded-full bg-primary text-primary-fg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BeanMark, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-display leading-none font-semibold", compact ? "text-2xl" : "text-4xl"),
			children: "Зерно"
		})]
	});
}
function Photo({ src, alt, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className: cn("bg-chip object-cover", className)
	});
}
function IconButton({ label, onClick, children, dot = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "relative grid size-11 place-items-center rounded-full text-fg",
		children: [children, dot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-2 rounded-full bg-primary" }) : null]
	});
}
function BackBar({ title, extra }) {
	const back = useUi((state) => state.back);
	const depth = useUi((state) => state.stack.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex h-14 shrink-0 items-center gap-1 px-1",
		children: [
			depth > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Назад",
				onClick: back,
				className: "grid size-11 place-items-center rounded-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "min-w-0 flex-1 truncate text-lg font-bold",
				children: title
			}),
			extra
		]
	});
}
function PrimaryButton({ children, onClick, disabled = false, type = "button" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		disabled,
		onClick,
		className: "flex h-12 w-full items-center justify-center rounded-full bg-primary px-4 text-base font-bold text-primary-fg disabled:opacity-40",
		children
	});
}
function Qty({ value, onDec, onInc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Меньше",
				onClick: onDec,
				className: "grid size-11 place-items-center rounded-full bg-chip",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 text-center text-sm font-bold",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Больше",
				onClick: onInc,
				className: "grid size-11 place-items-center rounded-full bg-primary text-primary-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
			})
		]
	});
}
function Stars({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1 text-sm font-semibold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-4 fill-star text-star" }), value.toFixed(1)]
	});
}
var FrameContext = (0, import_react.createContext)(null);
function Sheet({ title, onClose, children }) {
	const frame = (0, import_react.useContext)(FrameContext);
	const node = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-40 flex flex-col justify-end bg-ink/50",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": title,
			className: "sheet-body overflow-y-auto rounded-t-3xl bg-surface px-4 pt-3 pb-6",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Закрыть",
						onClick: onClose,
						className: "grid size-11 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				children
			]
		})
	});
	if (!frame) return node;
	return (0, import_react_dom.createPortal)(node, frame);
}
var CAT_ICONS = {
	coffee: Coffee,
	cold: GlassWater,
	signature: Sparkles,
	classic: CupSoda,
	bakery: Croissant,
	combo: Layers,
	favorites: Heart,
	promos: BadgePercent
};
function CatIcon({ name }) {
	const Icon = CAT_ICONS[name];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" });
}
var TABBED = /* @__PURE__ */ new Set([
	"home",
	"catalog",
	"cart",
	"profile",
	"orders"
]);
function showsTabs(kind) {
	return TABBED.has(kind);
}
function TabBar() {
	const screen = useScreen();
	const reset = useUi((state) => state.reset);
	const count = useApp((state) => cartCount(state.cart));
	const active = screen.kind === "catalog" ? "catalog" : screen.kind === "cart" ? "cart" : screen.kind === "profile" || screen.kind === "orders" ? "profile" : "home";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "grid shrink-0 grid-cols-4 border-t border-border bg-surface px-1 pt-1 pb-2",
		children: [
			{
				id: "home",
				label: "Главная",
				icon: House,
				go: () => reset({ kind: "home" })
			},
			{
				id: "catalog",
				label: "Меню",
				icon: Coffee,
				go: () => reset({
					kind: "catalog",
					mode: "all",
					title: "Меню"
				})
			},
			{
				id: "cart",
				label: "Корзина",
				icon: ShoppingBag,
				go: () => reset({ kind: "cart" })
			},
			{
				id: "profile",
				label: "Профиль",
				icon: User,
				go: () => reset({ kind: "profile" })
			}
		].map((tab) => {
			const Icon = tab.icon;
			const on = active === tab.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: tab.go,
				className: cn("flex flex-col items-center gap-0.5 py-1 text-xs font-semibold", on ? "text-primary" : "text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" }), tab.id === "cart" && count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -top-2 -right-3 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-xs leading-none font-bold text-primary-fg",
						children: count
					}) : null]
				}), tab.label]
			}, tab.id);
		})
	});
}
function Splash() {
	const enter = useApp((state) => state.enter);
	const reset = useUi((state) => state.reset);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-full overflow-hidden bg-ink text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/menu/hero.jpg",
				alt: "Чёрная чашка латте на кофейных зёрнах",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "splash-shade absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-full flex-col items-center justify-between px-6 py-10 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { light: true })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base",
						children: "Свежий кофе. Без очереди."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => {
							enter();
							reset({ kind: "home" });
						},
						children: "Начать"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm opacity-80",
						children: "Бишкек · кухня на Чуй · 07:00–23:00"
					})]
				})]
			})
		]
	});
}
function Home$2() {
	const city = useApp((state) => state.city);
	const setCity = useApp((state) => state.setCity);
	const notes = useApp((state) => state.notes);
	const orders = useApp((state) => state.orders);
	const push = useUi((state) => state.push);
	const [cities, setCities] = (0, import_react.useState)(false);
	const unread = notes.some((note) => !note.read);
	const current = orders.find((order) => order.status !== "delivered");
	const popular = productsFor("popular");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-scroll h-full overflow-y-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 px-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
						label: "Поиск",
						onClick: () => push({ kind: "search" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
						label: "Уведомления",
						dot: unread,
						onClick: () => push({ kind: "notifications" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center pr-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setCities(true),
					className: "flex items-center gap-2 px-4 py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Ваш город"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: city
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => push({
						kind: "map",
						orderId: current?.id ?? null
					}),
					className: "ml-auto h-11 rounded-full px-3 text-sm font-bold text-primary",
					children: "Карта"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => push({
						kind: "catalog",
						mode: "coffee",
						title: "Кофе"
					}),
					className: "relative block h-44 w-full overflow-hidden rounded-3xl text-left text-cream",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/menu/hero.jpg",
							alt: "",
							className: "absolute inset-0 size-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-shade absolute inset-0" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex h-full flex-col justify-end p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl leading-none font-semibold",
									children: "Ароматный кофе"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 max-w-56 text-sm",
									children: "День начинается с чашки, а не с очереди."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-3 inline-flex h-10 w-fit items-center rounded-full bg-cream px-4 text-sm font-bold text-ink",
									children: "Заказать"
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2 px-4 py-4",
				children: [
					{
						name: "coffee",
						label: "Кофе",
						go: () => push({
							kind: "catalog",
							mode: "coffee",
							title: "Кофе"
						})
					},
					{
						name: "cold",
						label: "Холодные",
						go: () => push({
							kind: "catalog",
							mode: "cold",
							title: "Холодные"
						})
					},
					{
						name: "signature",
						label: "Авторские",
						go: () => push({
							kind: "catalog",
							mode: "signature",
							title: "Авторские"
						})
					},
					{
						name: "classic",
						label: "Классика",
						go: () => push({
							kind: "catalog",
							mode: "classic",
							title: "Классика"
						})
					},
					{
						name: "bakery",
						label: "Выпечка",
						go: () => push({
							kind: "catalog",
							mode: "bakery",
							title: "Выпечка"
						})
					},
					{
						name: "combo",
						label: "Комбо",
						go: () => push({
							kind: "catalog",
							mode: "combo",
							title: "Комбо"
						})
					},
					{
						name: "favorites",
						label: "Избранное",
						go: () => push({ kind: "favorites" })
					},
					{
						name: "promos",
						label: "Акции",
						go: () => push({ kind: "promos" })
					}
				].map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: cat.go,
					className: "flex flex-col items-center gap-1.5 py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-14 place-items-center rounded-2xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatIcon, { name: cat.name })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold",
						children: cat.label
					})]
				}, cat.name))
			}),
			current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => push({
					kind: "order",
					orderId: current.id
				}),
				className: "mx-4 mb-4 flex items-center gap-3 rounded-3xl bg-surface p-3 text-left ring-1 ring-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-12 place-items-center rounded-2xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-sm font-bold",
							children: ["Заказ #", current.id]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-muted",
							children: current.status === "accepted" ? "Принят" : current.status === "cooking" ? "Готовится" : "Курьер в пути"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted" })
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "Популярное"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => push({
						kind: "catalog",
						mode: "popular",
						title: "Популярное"
					}),
					className: "text-sm font-semibold text-primary",
					children: "Все"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-3 overflow-x-auto px-4 pb-6",
				children: popular.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "w-40 shrink-0 overflow-hidden rounded-3xl bg-surface ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => push({
							kind: "product",
							productId: item.id
						}),
						className: "block w-full text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
							src: item.image,
							alt: item.name,
							className: "h-28 w-full"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-3 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: item.volume
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-3 pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold",
							children: som(item.price)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddDot, { productId: item.id })]
					})]
				}, item.id))
			}),
			cities ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Город",
				onClose: () => setCities(false),
				children: CITIES.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setCity(name);
						setCities(false);
					},
					className: "flex h-12 w-full items-center justify-between border-b border-line text-left font-semibold",
					children: [name, city === name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-primary",
						children: "выбран"
					}) : null]
				}, name))
			}) : null
		]
	});
}
var CHIPS = [
	{
		id: "all",
		label: "Все"
	},
	{
		id: "classic",
		label: "Классика"
	},
	{
		id: "signature",
		label: "Авторские"
	},
	{
		id: "cold",
		label: "Холодные"
	}
];
function Catalog({ mode, title }) {
	const push = useUi((state) => state.push);
	const [chip, setChip] = (0, import_react.useState)("all");
	const showChips = mode === "all" || mode === "coffee" || mode === "popular";
	const items = (0, import_react.useMemo)(() => {
		const base = productsFor(mode);
		if (!showChips || chip === "all") return base;
		return base.filter((item) => item.tags.includes(chip));
	}, [
		mode,
		chip,
		showChips
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, {
				title,
				extra: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Поиск",
					onClick: () => push({ kind: "search" }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
				})
			}),
			showChips ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto px-4 pb-3",
				children: CHIPS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setChip(item.id),
					className: chip === item.id ? "h-9 shrink-0 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg" : "h-9 shrink-0 rounded-full bg-chip px-4 text-sm font-semibold",
					children: item.label
				}, item.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted",
					children: "В этом разделе пока пусто."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-3xl bg-surface p-2 ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => push({
								kind: "product",
								productId: item.id
							}),
							className: "flex min-w-0 flex-1 items-center gap-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
								src: item.image,
								alt: "",
								className: "size-16 rounded-2xl"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-semibold",
										children: item.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted",
										children: item.volume
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-sm font-bold",
										children: som(item.price)
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddDot, { productId: item.id })]
					}, item.id))
				})
			})
		]
	});
}
function AddDot({ productId }) {
	const add = useApp((state) => state.addToCart);
	const showToast = useUi((state) => state.showToast);
	const name = productById(productId)?.name ?? "Позиция";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": `Добавить ${name}`,
		onClick: () => {
			add(productId, []);
			showToast(`${name} в корзине`);
		},
		className: "grid size-11 shrink-0 place-items-center rounded-full bg-primary text-primary-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
	});
}
function ProductView({ id }) {
	const product = productById(id);
	const back = useUi((state) => state.back);
	const add = useApp((state) => state.addToCart);
	const favorites = useApp((state) => state.favorites);
	const toggleFavorite = useApp((state) => state.toggleFavorite);
	const showToast = useUi((state) => state.showToast);
	const [qty, setQty] = (0, import_react.useState)(1);
	const [addons, setAddons] = (0, import_react.useState)([]);
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Такого напитка нет." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: back,
			className: "mt-3 font-semibold text-primary",
			children: "Назад"
		})]
	});
	const extra = addons.reduce((sum, addonId) => sum + (addonById(addonId)?.price ?? 0), 0);
	const loved = favorites.includes(product.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-scroll min-h-0 flex-1 overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-72",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
						src: product.image,
						alt: product.name,
						className: "size-full"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Назад",
						onClick: back,
						className: "absolute top-3 left-3 grid size-11 place-items-center rounded-full bg-surface text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-6 -rotate-90" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": loved ? "Убрать из избранного" : "В избранное",
						onClick: () => toggleFavorite(product.id),
						className: "absolute top-3 right-3 grid size-11 place-items-center rounded-full bg-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: loved ? "size-5 fill-primary text-primary" : "size-5" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-bold",
							children: product.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: product.volume
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-bold",
							children: som(product.price + extra)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 flex items-center gap-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stars, { value: product.rating }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [product.reviews, " отзывов"] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed",
						children: product.desc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 mb-2 font-bold",
						children: "Добавки"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: ADDONS.map((addon) => {
							const on = addons.includes(addon.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setAddons((current) => current.includes(addon.id) ? current.filter((item) => item !== addon.id) : [...current, addon.id]),
								className: "flex h-12 w-full items-center justify-between rounded-2xl bg-surface px-3 text-left ring-1 ring-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold",
										children: addon.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-semibold text-muted",
										children: ["+", som(addon.price)]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: on ? "grid size-6 place-items-center rounded-full bg-primary text-xs font-bold text-primary-fg" : "size-6 rounded-full ring-1 ring-border",
										"aria-hidden": "true",
										children: on ? "✓" : ""
									})
								]
							}) }, addon.id);
						})
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex shrink-0 items-center gap-3 border-t border-border bg-bg px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qty, {
				value: qty,
				onDec: () => setQty((value) => Math.max(1, value - 1)),
				onInc: () => setQty((value) => value + 1)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-w-0 flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
					onClick: () => {
						add(product.id, addons, qty);
						showToast(`${product.name} в корзине`);
					},
					children: ["В корзину · ", som((product.price + extra) * qty)]
				})
			})]
		})]
	});
}
function SearchScreen() {
	const push = useUi((state) => state.push);
	const [query, setQuery] = (0, import_react.useState)("");
	const items = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		if (!needle) return productsFor("all");
		return productsFor("all").filter((item) => item.name.toLowerCase().includes(needle) || item.desc.toLowerCase().includes(needle));
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Поиск" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-12 items-center gap-2 rounded-2xl bg-chip px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Латте, круассан, матча",
						className: "h-full w-full bg-transparent text-sm outline-none"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => push({
							kind: "product",
							productId: item.id
						}),
						className: "flex w-full items-center gap-3 rounded-3xl bg-surface p-2 text-left ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
							src: item.image,
							alt: "",
							className: "size-14 rounded-2xl"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-muted",
								children: som(item.price)
							})]
						})]
					}) }, item.id))
				}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted",
					children: "Ничего не нашли. Попробуйте «латте»."
				}) : null]
			})
		]
	});
}
function CartScreen() {
	const cart = useApp((state) => state.cart);
	const promo = useApp((state) => state.promo);
	const setQty = useApp((state) => state.setQty);
	const clearCart = useApp((state) => state.clearCart);
	const applyPromo = useApp((state) => state.applyPromo);
	const clearPromo = useApp((state) => state.clearPromo);
	const push = useUi((state) => state.push);
	const showToast = useUi((state) => state.showToast);
	const [code, setCode] = (0, import_react.useState)("");
	const subtotal = cartSubtotal(cart);
	const discount = promoDiscount(promo, subtotal);
	const total = Math.max(0, subtotal - discount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex h-14 items-center justify-between px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-bold",
				children: "Корзина"
			}), cart.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: clearCart,
				className: "text-sm font-semibold text-primary",
				children: "Очистить"
			}) : null]
		}), cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col items-center justify-center px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
					src: "/menu/latte.jpg",
					alt: "",
					className: "size-28 rounded-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg font-bold",
					children: "Корзина пуста"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Латте, раф или круассан — кухня на Чуй уже открыта."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => push({
							kind: "catalog",
							mode: "coffee",
							title: "Кофе"
						}),
						children: "К кофе"
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: cart.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartRow, {
						line,
						onQty: (qty) => setQty(line.key, qty)
					}, line.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 flex gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						const ok = applyPromo(code);
						showToast(ok ? `Промокод ${code.trim().toUpperCase()} применён` : "Такого промокода нет");
						if (ok) setCode("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: code,
						onChange: (event) => setCode(event.target.value),
						placeholder: "Промокод",
						className: "h-12 min-w-0 flex-1 rounded-2xl bg-chip px-4 text-sm outline-none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "h-12 rounded-2xl bg-chip px-4 text-sm font-bold",
						children: "Ок"
					})]
				}),
				promo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-center justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						promo,
						" · −",
						som(discount)
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: clearPromo,
						className: "font-semibold text-primary",
						children: "Убрать"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "Попробуйте ZERNO20 или SWEET50"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: itemsLabel(cart.reduce((sum, line) => sum + line.qty, 0))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xl font-bold",
						children: som(total)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => push({ kind: "checkout" }),
						children: "Оформить заказ"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: clearCart,
					className: "mx-auto mt-3 flex items-center gap-1 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Очистить корзину"]
				})
			]
		})]
	});
}
function CartRow({ line, onQty }) {
	const product = productById(line.productId);
	if (!product) return null;
	const addonNames = line.addonIds.map((id) => addonById(id)?.name).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 rounded-3xl bg-surface p-2 ring-1 ring-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: product.image,
				alt: "",
				className: "size-16 rounded-2xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted",
						children: [
							product.volume,
							addonNames.length ? ` · ${addonNames.join(", ")}` : "",
							line.priceOverride === 0 ? " · за баллы" : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold",
						children: som(cartUnit(line) * line.qty)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qty, {
				value: line.qty,
				onDec: () => onQty(line.qty - 1),
				onInc: () => onQty(line.qty + 1)
			})
		]
	});
}
function Checkout() {
	const cart = useApp((state) => state.cart);
	const promo = useApp((state) => state.promo);
	const bonuses = useApp((state) => state.bonuses);
	const addresses = useApp((state) => state.addresses);
	const addressId = useApp((state) => state.addressId);
	const setAddress = useApp((state) => state.setAddress);
	const payment = useApp((state) => state.payment);
	const setPayment = useApp((state) => state.setPayment);
	const placeOrder = useApp((state) => state.placeOrder);
	const reset = useUi((state) => state.reset);
	const showToast = useUi((state) => state.showToast);
	const [mode, setMode] = (0, import_react.useState)("delivery");
	const [eta, setEta] = (0, import_react.useState)(ETAS[0]);
	const [comment, setComment] = (0, import_react.useState)("");
	const [useBonus, setUseBonus] = (0, import_react.useState)(false);
	const [pickAddress, setPickAddress] = (0, import_react.useState)(false);
	const [pickEta, setPickEta] = (0, import_react.useState)(false);
	const subtotal = cartSubtotal(cart);
	const discount = promoDiscount(promo, subtotal);
	const after = Math.max(0, subtotal - discount);
	const bonusSpend = useBonus ? Math.min(bonuses, Math.floor(after * .3)) : 0;
	const total = after - bonusSpend;
	const address = addresses.find((item) => item.id === addressId) ?? addresses[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Оформление" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 rounded-full bg-chip p-1",
						children: [["delivery", "Доставка"], ["pickup", "Самовывоз"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode(id),
							className: mode === id ? "h-10 rounded-full bg-primary text-sm font-bold text-primary-fg" : "h-10 rounded-full text-sm font-semibold",
							children: label
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => mode === "delivery" ? setPickAddress(true) : void 0,
						className: "mt-4 flex h-14 w-full items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5 shrink-0 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: mode === "delivery" ? "Адрес доставки" : "Кафе"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-semibold",
									children: mode === "delivery" ? address?.text : "пр. Чуй, 114 — Зерно"
								})]
							}),
							mode === "delivery" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted" }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setPickEta(true),
						className: "mt-2 flex h-14 w-full items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: "Время"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-semibold",
									children: eta
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 block text-sm font-semibold",
						children: ["Комментарий", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: comment,
							onChange: (event) => setComment(event.target.value),
							placeholder: "Например: без сиропа, позвоните у подъезда",
							className: "mt-2 h-24 w-full resize-none rounded-2xl bg-chip p-3 text-sm font-normal outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 mb-2 font-bold",
						children: "Оплата"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: PAYMENTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPayment(item.id),
							className: "flex h-12 w-full items-center justify-between rounded-2xl bg-surface px-3 ring-1 ring-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: payment === item.id ? "size-3 rounded-full bg-primary" : "size-3 rounded-full ring-1 ring-border" })]
						}) }, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setUseBonus((value) => !value),
						className: "mt-3 flex h-12 w-full items-center justify-between rounded-2xl bg-surface px-3 ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-semibold",
							children: ["Списать баллы · ", bonuses]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: useBonus ? "text-sm font-bold text-primary" : "text-sm text-muted",
							children: useBonus ? `−${som(bonusSpend)}` : "выкл"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Итого"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xl font-bold",
							children: som(total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
							disabled: cart.length === 0,
							onClick: () => {
								const id = placeOrder({
									mode,
									eta,
									comment,
									bonusSpend,
									total
								});
								if (!id) {
									showToast("Корзина пуста");
									return;
								}
								showToast(`Заказ #${id} принят`);
								reset({
									kind: "order",
									orderId: id
								});
							},
							children: ["Оплатить ", som(total)]
						})
					})
				]
			}),
			pickAddress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: "Адрес",
				onClose: () => setPickAddress(false),
				children: [addresses.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setAddress(item.id);
						setPickAddress(false);
					},
					className: "flex h-14 w-full flex-col items-start justify-center border-b border-line text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-bold",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: item.text
					})]
				}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setPickAddress(false);
						useUi.getState().push({ kind: "addresses" });
					},
					className: "mt-3 h-11 text-sm font-semibold text-primary",
					children: "Новый адрес"
				})]
			}) : null,
			pickEta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Когда привезти",
				onClose: () => setPickEta(false),
				children: ETAS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setEta(item);
						setPickEta(false);
					},
					className: "flex h-12 w-full items-center border-b border-line text-left font-semibold",
					children: item
				}, item))
			}) : null
		]
	});
}
var STEPS = [
	{
		id: "accepted",
		label: "Заказ принят"
	},
	{
		id: "cooking",
		label: "Готовится"
	},
	{
		id: "enroute",
		label: "В пути"
	},
	{
		id: "delivered",
		label: "Доставлен"
	}
];
function lonTile(lon, zoom) {
	return (lon + 180) / 360 * 2 ** zoom;
}
function latTile(lat, zoom) {
	const rad = lat * Math.PI / 180;
	return (1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * 2 ** zoom;
}
function MapCanvas({ center, zoom, pins }) {
	const theme = useApp((state) => state.theme);
	const [size, setSize] = (0, import_react.useState)({
		w: 360,
		h: 420
	});
	const [box, setBox] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!box) return;
		const apply = () => setSize({
			w: Math.max(1, box.clientWidth),
			h: Math.max(1, box.clientHeight)
		});
		apply();
		const observer = new ResizeObserver(apply);
		observer.observe(box);
		return () => observer.disconnect();
	}, [box]);
	const tiles = (0, import_react.useMemo)(() => {
		const cx = lonTile(center.lng, zoom);
		const cy = latTile(center.lat, zoom);
		const tilesX = Math.max(2, Math.ceil(size.w / 256) + 2);
		const tilesY = Math.max(2, Math.ceil(size.h / 256) + 2);
		const left = Math.floor(cx - tilesX / 2);
		const top = Math.floor(cy - tilesY / 2);
		const originX = size.w / 2 - (cx - left) * 256;
		const originY = size.h / 2 - (cy - top) * 256;
		const max = 2 ** zoom;
		const list = [];
		for (let ix = 0; ix < tilesX; ix += 1) for (let iy = 0; iy < tilesY; iy += 1) {
			const x = left + ix;
			const y = top + iy;
			if (y < 0 || y >= max) continue;
			const wrapped = (x % max + max) % max;
			const src = theme === "dark" ? `https://${"abcd"[(wrapped + y) % 4]}.basemaps.cartocdn.com/dark_all/${zoom}/${wrapped}/${y}.png` : `https://${"abcd"[(wrapped + y) % 4]}.basemaps.cartocdn.com/rastertiles/voyager/${zoom}/${wrapped}/${y}.png`;
			list.push({
				key: `${zoom}-${wrapped}-${y}`,
				src,
				left: originX + ix * 256,
				top: originY + iy * 256
			});
		}
		return {
			list,
			originX,
			originY,
			left,
			top
		};
	}, [
		center.lat,
		center.lng,
		zoom,
		size.w,
		size.h,
		theme
	]);
	const place = (lat, lng) => ({
		left: tiles.originX + (lonTile(lng, zoom) - tiles.left) * 256,
		top: tiles.originY + (latTile(lat, zoom) - tiles.top) * 256
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: setBox,
		className: "relative h-full overflow-hidden bg-chip",
		children: [
			tiles.list.map((tile) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				alt: "",
				src: tile.src,
				className: "pointer-events-none absolute size-64 max-w-none",
				style: {
					left: tile.left,
					top: tile.top
				}
			}, tile.key)),
			pins.map((pin) => {
				const pos = place(pin.lat, pin.lng);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute",
					style: {
						left: pos.left,
						top: pos.top
					},
					children: pin.node
				}, pin.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute bottom-1 left-2 rounded-full bg-surface px-2 py-0.5 text-xs text-muted",
				children: "© OpenStreetMap · CARTO"
			})
		]
	});
}
function MapScreen({ orderId }) {
	const order = useApp((state) => state.orders.find((item) => item.id === orderId) ?? null);
	const addresses = useApp((state) => state.addresses);
	const now = useClock((state) => state.now);
	const showToast = useUi((state) => state.showToast);
	const push = useUi((state) => state.push);
	const [zoom, setZoom] = (0, import_react.useState)(13);
	const [query, setQuery] = (0, import_react.useState)("");
	const [focus, setFocus] = (0, import_react.useState)(null);
	const [me, setMe] = (0, import_react.useState)(null);
	const found = (0, import_react.useMemo)(() => [...CAFES.map((cafe) => ({
		id: cafe.id,
		title: cafe.name,
		text: cafe.address,
		lat: cafe.lat,
		lng: cafe.lng
	})), ...addresses.map((item) => ({
		id: item.id,
		title: item.label,
		text: item.text,
		lat: item.lat,
		lng: item.lng
	}))], [addresses]).filter((place) => {
		const needle = query.trim().toLowerCase();
		if (!needle) return false;
		return place.title.toLowerCase().includes(needle) || place.text.toLowerCase().includes(needle);
	});
	const anchor = order ?? {
		lat: addresses[0]?.lat ?? CAFE.lat,
		lng: addresses[0]?.lng ?? CAFE.lng
	};
	const center = focus ?? {
		lat: (CAFE.lat + anchor.lat) / 2,
		lng: (CAFE.lng + anchor.lng) / 2
	};
	const moving = order && order.mode === "delivery" && order.status !== "delivered" ? courierPoint(order, now) : null;
	const pins = [...CAFES.map((cafe) => ({
		id: cafe.id,
		lat: cafe.lat,
		lng: cafe.lng,
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex -translate-x-1/2 -translate-y-full flex-col items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-surface px-2 py-1 text-xs font-bold shadow",
				children: cafe.name.replace("Зерно ", "")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-full bg-primary" })]
		})
	})), {
		id: "drop",
		lat: anchor.lat,
		lng: anchor.lng,
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-9 -translate-x-1/2 -translate-y-full place-items-center rounded-full bg-fg text-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" })
		})
	}];
	if (moving) pins.push({
		id: "courier",
		lat: moving.lat,
		lng: moving.lng,
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-primary-fg ring-4 ring-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bike, { className: "size-5" })
		})
	});
	if (me) pins.push({
		id: "me",
		lat: me.lat,
		lng: me.lng,
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block size-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-success ring-4 ring-surface" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Карта" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-12 items-center gap-2 rounded-2xl bg-chip px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Поиск адреса или кафе",
						className: "h-full w-full bg-transparent text-sm outline-none"
					})]
				})
			}),
			query.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4",
				children: [found.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-6 text-sm text-muted",
					children: "Ничего не нашли"
				}) : null, found.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setFocus({
							lat: place.lat,
							lng: place.lng
						});
						setZoom(15);
						setQuery("");
					},
					className: "flex h-14 w-full flex-col items-start justify-center border-b border-line text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-bold",
						children: place.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: place.text
					})]
				}) }, place.id))]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {
					center,
					zoom,
					pins
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute top-3 right-3 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Ближе",
							onClick: () => setZoom((value) => Math.min(16, value + 1)),
							className: "grid size-11 place-items-center rounded-full bg-surface shadow",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Дальше",
							onClick: () => setZoom((value) => Math.max(12, value - 1)),
							className: "grid size-11 place-items-center rounded-full bg-surface shadow",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Моё место",
							onClick: () => {
								if (!navigator.geolocation) {
									showToast("Геолокация недоступна");
									return;
								}
								navigator.geolocation.getCurrentPosition((pos) => {
									const lat = pos.coords.latitude;
									const lng = pos.coords.longitude;
									if (Math.abs(lat - CAFE.lat) > .6 || Math.abs(lng - CAFE.lng) > .6) {
										showToast("Вы далеко от Бишкека — карта остаётся на заказе");
										return;
									}
									setMe({
										lat,
										lng
									});
									setFocus({
										lat,
										lng
									});
									setZoom(15);
								}, () => showToast("Не удалось получить геолокацию"), {
									enableHighAccuracy: true,
									timeout: 8e3
								});
							},
							className: "grid size-11 place-items-center rounded-full bg-surface shadow",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, { className: "size-5" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 border-t border-border bg-surface px-4 py-3",
				children: order ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-12 place-items-center rounded-full bg-primary text-sm font-bold text-primary-fg",
							children: "ТС"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold",
								children: order.status === "delivered" ? "Заказ доставлен" : "Тимур уже на смене"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: etaLeft(order, now)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => push({
								kind: "order",
								orderId: order.id
							}),
							className: "text-sm font-bold text-primary",
							children: "Заказ"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold",
					children: "Две кофейни в городе"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Оформите заказ — курьер поедет от Чуй."
				})] })
			})
		]
	});
}
function OrderView({ id }) {
	const order = useApp((state) => state.orders.find((item) => item.id === id));
	const chat = useApp((state) => state.courierChat);
	const sendCourier = useApp((state) => state.sendCourier);
	const repeatOrder = useApp((state) => state.repeatOrder);
	const now = useClock((state) => state.now);
	const back = useUi((state) => state.back);
	const stack = useUi((state) => state.stack);
	const reset = useUi((state) => state.reset);
	const push = useUi((state) => state.push);
	const showToast = useUi((state) => state.showToast);
	const [openChat, setOpenChat] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	if (!order) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Заказ не найден." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-3 font-semibold text-primary",
			onClick: () => reset({ kind: "home" }),
			children: "На главную"
		})]
	});
	const leave = () => {
		if (stack.length < 2) reset({ kind: "home" });
		else back();
	};
	const currentIndex = STEPS.findIndex((step) => step.id === order.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-14 shrink-0 items-center gap-1 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Назад",
					onClick: leave,
					className: "grid size-11 place-items-center rounded-full text-lg",
					children: "←"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-lg font-bold",
					children: ["Заказ #", order.id]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-3xl bg-surface p-4 ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-14 place-items-center rounded-full bg-primary text-lg font-bold text-primary-fg",
								children: "ТС"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: "Тимур Садыков"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-sm text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stars, { value: 4.9 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "256 заказов" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Toyota Corolla · 01 KG 452"
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => showToast("Звоним Тимуру Садыкову…"),
								className: "grid size-11 flex-1 place-items-center rounded-2xl bg-primary-soft text-primary",
								"aria-label": "Позвонить курьеру",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOpenChat(true),
								className: "grid size-11 flex-1 place-items-center rounded-2xl bg-chip",
								"aria-label": "Написать курьеру",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 flex flex-col gap-0 px-1",
						children: STEPS.map((step, index) => {
							const hit = order.history.find((item) => item.status === step.id);
							const done = index < currentIndex;
							const current = index === currentIndex;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: done ? "grid size-6 place-items-center rounded-full bg-success text-cream" : current ? "grid size-6 place-items-center rounded-full bg-primary text-primary-fg" : "grid size-6 place-items-center rounded-full bg-chip text-muted",
										children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-current" })
									}), index < STEPS.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-px flex-1 bg-line" }) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex min-h-12 flex-1 items-start justify-between pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: current ? "font-bold" : "font-semibold",
										children: step.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: hit ? clock(hit.at) : ""
									})]
								})]
							}, step.id);
						})
					}),
					order.status === "enroute" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-2xl bg-success-soft px-3 py-3 text-sm text-success",
						children: [
							"Курьер уже в пути. Ориентир — ",
							etaLeft(order, now),
							"."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: () => push({
								kind: "map",
								orderId: order.id
							}),
							children: "Открыть карту"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 mb-2 font-bold",
						children: "Состав"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: order.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
									src: line.image,
									alt: "",
									className: "size-12 rounded-xl"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1 text-sm font-semibold",
									children: [
										line.name,
										" × ",
										line.qty
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold",
									children: som(line.unit * line.qty)
								})
							]
						}, `${line.productId}-${line.name}`))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: order.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							order.payment,
							" · ",
							order.eta
						]
					}),
					order.comment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: ["Комментарий: ", order.comment]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Итого"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xl font-bold",
							children: som(order.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							repeatOrder(order.id);
							showToast("Состав снова в корзине");
							push({ kind: "cart" });
						},
						className: "mt-4 h-12 w-full rounded-full bg-chip text-sm font-bold",
						children: "Повторить заказ"
					})
				]
			}),
			openChat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Тимур",
				onClose: () => setOpenChat(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thread, {
					items: chat,
					mineLabel: "Вы",
					themLabel: "Тимур",
					value: text,
					onChange: setText,
					onSend: () => {
						sendCourier(text);
						setText("");
					}
				})
			}) : null
		]
	});
}
function OrdersScreen() {
	const orders = useApp((state) => state.orders);
	const push = useUi((state) => state.push);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const list = orders.filter((order) => filter === "all" || order.mode === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "flex h-14 items-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-bold",
					children: "Мои заказы"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 px-4 pb-3",
				children: [
					["all", "Все"],
					["delivery", "Доставки"],
					["pickup", "Самовывоз"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(id),
					className: filter === id ? "h-9 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg" : "h-9 rounded-full bg-chip px-4 text-sm font-semibold",
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: [list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted",
					children: "Таких заказов пока нет."
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-3",
					children: list.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
						order,
						onOpen: () => push({
							kind: "order",
							orderId: order.id
						})
					}, order.id))
				})]
			})
		]
	});
}
function OrderCard({ order, onOpen }) {
	const label = order.status === "delivered" ? "Доставлен" : order.status === "enroute" ? "В пути" : order.status === "cooking" ? "Готовится" : "Принят";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "w-full rounded-3xl bg-surface p-3 text-left ring-1 ring-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: order.status === "delivered" ? "text-sm font-bold text-success" : "text-sm font-bold text-primary",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: dayTime(order.createdAt)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-1 block text-xs text-muted",
				children: ["#", order.id]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-2 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex min-w-0 flex-1 gap-1",
					children: order.lines.slice(0, 3).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
						src: line.image,
						alt: "",
						className: "size-12 rounded-xl"
					}, line.productId + line.name))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-bold",
					children: som(order.total)
				})]
			})
		]
	}) });
}
function Thread({ items, themLabel, value, onChange, onSend }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex max-h-64 flex-col gap-2 overflow-y-auto",
		children: [items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted",
			children: [
				"Напишите ",
				themLabel.toLowerCase(),
				" — ответ придёт сразу."
			]
		}) : null, items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: item.from === "me" ? "ml-8 rounded-2xl bg-primary px-3 py-2 text-sm text-primary-fg" : "mr-8 rounded-2xl bg-chip px-3 py-2 text-sm",
			children: item.text
		}, item.id))]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-3 flex gap-2",
		onSubmit: (event) => {
			event.preventDefault();
			onSend();
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (event) => onChange(event.target.value),
			placeholder: "Сообщение",
			className: "h-12 min-w-0 flex-1 rounded-2xl bg-chip px-3 text-sm outline-none"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "submit",
			className: "h-12 rounded-2xl bg-primary px-4 text-sm font-bold text-primary-fg",
			children: "Ок"
		})]
	})] });
}
function ProfileScreen() {
	const profile = useApp((state) => state.profile);
	const theme = useApp((state) => state.theme);
	const toggleTheme = useApp((state) => state.toggleTheme);
	const bonuses = useApp((state) => state.bonuses);
	const updateProfile = useApp((state) => state.updateProfile);
	const push = useUi((state) => state.push);
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(profile);
	const initials = profile.name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? "").join("");
	const rows = [
		{
			label: "Мои заказы",
			icon: Ticket,
			go: () => push({ kind: "orders" })
		},
		{
			label: "Избранное",
			icon: Heart,
			go: () => push({ kind: "favorites" })
		},
		{
			label: "Адреса доставки",
			icon: MapPin,
			go: () => push({ kind: "addresses" })
		},
		{
			label: "Способы оплаты",
			icon: Ticket,
			go: () => push({ kind: "payments" })
		},
		{
			label: "Бонусы и скидки",
			hint: `${bonuses} баллов`,
			icon: Gift,
			go: () => push({ kind: "promos" })
		},
		{
			label: "Уведомления",
			icon: Bell,
			go: () => push({ kind: "notifications" })
		},
		{
			label: "Помощь",
			icon: MessageSquare,
			go: () => push({ kind: "support" })
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-scroll h-full overflow-y-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-bold",
					children: "Профиль"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Тема",
					onClick: toggleTheme,
					className: "grid size-11 place-items-center rounded-full bg-chip",
					children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setDraft(profile);
					setEdit(true);
				},
				className: "flex w-full items-center gap-3 px-4 py-4 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-16 place-items-center rounded-full bg-primary-soft text-lg font-bold text-primary",
					children: initials
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-lg font-bold",
							children: profile.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: profile.phone
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-muted",
							children: profile.email
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: toggleTheme,
				className: "mx-4 mb-2 flex h-12 w-auto items-center justify-between rounded-2xl bg-chip px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-semibold",
					children: "Тёмная тема"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: theme === "dark" ? "text-sm font-bold text-primary" : "text-sm text-muted",
					children: theme === "dark" ? "вкл" : "выкл"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "px-4",
				children: rows.map((row) => {
					const Icon = row.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: row.go,
						className: "flex h-14 w-full items-center gap-3 border-b border-line text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 font-semibold",
								children: row.label
							}),
							row.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-primary",
								children: row.hint
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted" })
						]
					}) }, row.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-6 text-sm text-muted",
				children: "Зерно · Бишкек · кухня на пр. Чуй, 114"
			}),
			edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Ваши данные",
				onClose: () => setEdit(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex flex-col gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						updateProfile({
							name: draft.name.trim() || profile.name,
							phone: draft.phone.trim() || profile.phone,
							email: draft.email.trim() || profile.email
						});
						setEdit(false);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-semibold",
							children: ["Имя", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.name,
								onChange: (event) => setDraft({
									...draft,
									name: event.target.value
								}),
								className: "mt-1 h-12 w-full rounded-2xl bg-chip px-3 font-normal outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-semibold",
							children: ["Телефон", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.phone,
								onChange: (event) => setDraft({
									...draft,
									phone: event.target.value
								}),
								className: "mt-1 h-12 w-full rounded-2xl bg-chip px-3 font-normal outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-semibold",
							children: ["Почта", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.email,
								onChange: (event) => setDraft({
									...draft,
									email: event.target.value
								}),
								className: "mt-1 h-12 w-full rounded-2xl bg-chip px-3 font-normal outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							type: "submit",
							children: "Сохранить"
						})
					]
				})
			}) : null
		]
	});
}
function FavoritesScreen() {
	const favorites = useApp((state) => state.favorites);
	const toggle = useApp((state) => state.toggleFavorite);
	const push = useUi((state) => state.push);
	const [tab, setTab] = (0, import_react.useState)("goods");
	const items = PRODUCTS.filter((item) => favorites.includes(item.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Избранное" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 px-4 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab("goods"),
					className: tab === "goods" ? "h-10 rounded-full bg-primary text-sm font-bold text-primary-fg" : "h-10 rounded-full bg-chip text-sm font-semibold",
					children: "Товары"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab("cafes"),
					className: tab === "cafes" ? "h-10 rounded-full bg-primary text-sm font-bold text-primary-fg" : "h-10 rounded-full bg-chip text-sm font-semibold",
					children: "Кофейни"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: tab === "goods" ? items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-10 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: "Пока пусто"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Сердечко на карточке сохранит напиток здесь."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-3xl bg-surface p-2 ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => push({
								kind: "product",
								productId: item.id
							}),
							className: "flex min-w-0 flex-1 items-center gap-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
								src: item.image,
								alt: "",
								className: "size-16 rounded-2xl"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-muted",
								children: som(item.price)
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Убрать",
							onClick: () => toggle(item.id),
							className: "grid size-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-5 fill-primary text-primary" })
						})]
					}, item.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: CAFES.map((cafe) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-3xl bg-surface p-4 ring-1 ring-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: cafe.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: cafe.address
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									cafe.hours,
									" · ",
									cafe.km
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => push({
									kind: "map",
									orderId: null
								}),
								className: "mt-2 text-sm font-bold text-primary",
								children: "На карте"
							})
						]
					}, cafe.id))
				})
			})
		]
	});
}
function PromosScreen() {
	const bonuses = useApp((state) => state.bonuses);
	const claimGift = useApp((state) => state.claimGift);
	const applyPromo = useApp((state) => state.applyPromo);
	const push = useUi((state) => state.push);
	const showToast = useUi((state) => state.showToast);
	const progress = Math.min(100, Math.round(bonuses / 500 * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Акции" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => push({
						kind: "product",
						productId: "combo-sweet"
					}),
					className: "relative block h-40 w-full overflow-hidden rounded-3xl text-left text-cream",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/menu/hero.jpg",
							alt: "",
							className: "absolute inset-0 size-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-shade absolute inset-0" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative flex h-full flex-col justify-end p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl leading-none font-semibold",
								children: "Кофе и круассан"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 text-sm",
								children: ["Сладкая пауза — ", som(220)]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mt-4 rounded-3xl bg-surface p-4 ring-1 ring-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-bold",
								children: "Бонусная программа"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-5 text-star" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "5% с заказа возвращаются баллами. 500 баллов — капучино."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-2xl font-bold",
							children: [bonuses, " баллов"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-2 overflow-hidden rounded-full bg-chip",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-primary",
								style: { width: `${progress}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								disabled: bonuses < 500,
								onClick: () => {
									if (!claimGift()) {
										showToast("Нужно 500 баллов");
										return;
									}
									showToast("Капучино добавлен за баллы");
									push({ kind: "cart" });
								},
								children: bonuses >= 500 ? "Забрать капучино" : `Ещё ${500 - bonuses} до капучино`
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 flex flex-col gap-2",
					children: [["ZERNO20", "−20% на всю корзину"], ["SWEET50", "−50 с на заказ"]].map(([code, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							applyPromo(code);
							showToast(`${code} применён в корзине`);
							push({ kind: "cart" });
						},
						className: "flex h-16 w-full items-center justify-between rounded-2xl bg-surface px-3 text-left ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-bold",
							children: code
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: text
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold text-primary",
							children: "Применить"
						})]
					}) }, code))
				})
			]
		})]
	});
}
function NotesScreen() {
	const notes = useApp((state) => state.notes);
	const markNotesRead = useApp((state) => state.markNotesRead);
	(0, import_react.useEffect)(() => {
		markNotesRead();
	}, [markNotesRead]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Уведомления" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-3xl bg-surface p-3 ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold",
						children: note.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: note.body
					})]
				}, note.id))
			})
		})]
	});
}
function SupportScreen() {
	const thread = useApp((state) => state.support);
	const sendSupport = useApp((state) => state.sendSupport);
	const showToast = useUi((state) => state.showToast);
	const [open, setOpen] = (0, import_react.useState)(FAQ[0]?.q ?? null);
	const [chat, setChat] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Поддержка" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 text-sm font-bold text-muted",
						children: "Частые вопросы"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: FAQ.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl bg-surface ring-1 ring-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOpen((value) => value === item.q ? null : item.q),
								className: "flex min-h-12 w-full items-center justify-between px-3 text-left text-sm font-semibold",
								children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: open === item.q ? "size-4 rotate-90" : "size-4" })]
							}), open === item.q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-3 pb-3 text-sm text-muted",
								children: item.a
							}) : null]
						}, item.q))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setChat(true),
							className: "flex h-14 items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "Написать в поддержку"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => showToast("Звоним на +996 312 90 00 20"),
							className: "flex h-14 items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "Позвонить"
							})]
						})]
					})
				]
			}),
			chat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Поддержка",
				onClose: () => setChat(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thread, {
					items: thread,
					mineLabel: "Вы",
					themLabel: "Поддержка",
					value: text,
					onChange: setText,
					onSend: () => {
						sendSupport(text);
						setText("");
					}
				})
			}) : null
		]
	});
}
function AddressesScreen() {
	const addresses = useApp((state) => state.addresses);
	const addressId = useApp((state) => state.addressId);
	const setAddress = useApp((state) => state.setAddress);
	const addAddress = useApp((state) => state.addAddress);
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Адреса" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: addresses.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setAddress(item.id),
				className: "flex h-16 w-full items-center justify-between border-b border-line text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-semibold",
					children: item.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm text-muted",
					children: item.text
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: item.id === addressId ? "size-3 rounded-full bg-primary" : "size-3 rounded-full ring-1 ring-border" })]
			}) }, item.id)) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex flex-col gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					addAddress(text);
					setText("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					onChange: (event) => setText(event.target.value),
					placeholder: "Новый адрес, подъезд, квартира",
					className: "h-12 rounded-2xl bg-chip px-3 text-sm outline-none"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					disabled: !text.trim(),
					children: "Добавить адрес"
				})]
			})]
		})]
	});
}
function PaymentsScreen() {
	const payment = useApp((state) => state.payment);
	const setPayment = useApp((state) => state.setPayment);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackBar, { title: "Оплата" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "px-4",
			children: PAYMENTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPayment(item.id),
				className: "flex h-14 w-full items-center justify-between border-b border-line text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: payment === item.id ? "size-3 rounded-full bg-primary" : "size-3 rounded-full ring-1 ring-border" })]
			}) }, item.id))
		})]
	});
}
function View({ screen }) {
	switch (screen.kind) {
		case "splash": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
		case "home": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$2, {});
		case "catalog": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Catalog, {
			mode: screen.mode,
			title: screen.title
		});
		case "product": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductView, { id: screen.productId });
		case "cart": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartScreen, {});
		case "checkout": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkout, {});
		case "search": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchScreen, {});
		case "order": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderView, { id: screen.orderId });
		case "map": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapScreen, { orderId: screen.orderId });
		case "profile": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, {});
		case "orders": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersScreen, {});
		case "favorites": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoritesScreen, {});
		case "promos": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromosScreen, {});
		case "notifications": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesScreen, {});
		case "support": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportScreen, {});
		case "addresses": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressesScreen, {});
		case "payments": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentsScreen, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$2, {});
	}
}
function ZernoApp() {
	const screen = useScreen();
	const theme = useApp((state) => state.theme);
	const toast = useUi((state) => state.toast);
	const [frame, setFrame] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const pending = useApp.persist.rehydrate();
		Promise.resolve(pending).finally(() => {
			const next = useApp.getState().theme;
			document.documentElement.classList.toggle("dark", next === "dark");
			document.documentElement.style.colorScheme = next;
			const top = useUi.getState().stack.at(-1);
			if (useApp.getState().entered && top?.kind === "splash") useUi.getState().reset({ kind: "home" });
		});
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.classList.toggle("dark", theme === "dark");
		document.documentElement.style.colorScheme = theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const now = Date.now();
			useClock.setState({ now });
			useApp.getState().advanceOrders(now);
		}, 1e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-dvh items-center justify-center overflow-hidden bg-canvas",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrameContext.Provider, {
			value: frame,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: setFrame,
				className: "app-frame relative flex flex-col overflow-hidden bg-bg md:ring-1 md:ring-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "screen-in min-h-0 flex-1 overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, { screen })
					}, screenKey(screen)),
					showsTabs(screen.kind) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBar, {}) : null,
					toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						className: "pointer-events-none absolute inset-x-4 top-3 z-50 rounded-full bg-ink px-4 py-2 text-center text-sm font-semibold text-cream",
						children: toast
					}) : null
				]
			})
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZernoApp, {});
}
//#endregion
export { Home as component };
