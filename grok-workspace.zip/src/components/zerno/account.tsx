import { useEffect, useState } from "react";
import {
  Bell,
  ChevronRight,
  Gift,
  Heart,
  MapPin,
  MessageSquare,
  Moon,
  Phone,
  Sun,
  Ticket,
} from "lucide-react";
import { CAFES, FAQ, PAYMENTS, PRODUCTS, som, type PaymentId } from "@/lib/zerno/data";
import { useUi } from "@/lib/zerno/nav";
import { useApp } from "@/lib/zerno/store";
import { BackBar, Photo, PrimaryButton, Sheet } from "@/components/zerno/parts";
import { Thread } from "@/components/zerno/ride";

export function ProfileScreen() {
  const profile = useApp((state) => state.profile);
  const theme = useApp((state) => state.theme);
  const toggleTheme = useApp((state) => state.toggleTheme);
  const bonuses = useApp((state) => state.bonuses);
  const updateProfile = useApp((state) => state.updateProfile);
  const push = useUi((state) => state.push);
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState(profile);
  const initials = profile.name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");

  const rows: { label: string; hint?: string; go: () => void; icon: typeof Bell }[] = [
    { label: "Мои заказы", icon: Ticket, go: () => push({ kind: "orders" }) },
    { label: "Избранное", icon: Heart, go: () => push({ kind: "favorites" }) },
    { label: "Адреса доставки", icon: MapPin, go: () => push({ kind: "addresses" }) },
    { label: "Способы оплаты", icon: Ticket, go: () => push({ kind: "payments" }) },
    { label: "Бонусы и скидки", hint: `${bonuses} баллов`, icon: Gift, go: () => push({ kind: "promos" }) },
    { label: "Уведомления", icon: Bell, go: () => push({ kind: "notifications" }) },
    { label: "Помощь", icon: MessageSquare, go: () => push({ kind: "support" }) },
  ];

  return (
    <div className="app-scroll h-full overflow-y-auto">
      <header className="flex items-center justify-between px-4 pt-4">
        <h1 className="text-lg font-bold">Профиль</h1>
        <button type="button" aria-label="Тема" onClick={toggleTheme} className="grid size-11 place-items-center rounded-full bg-chip">
          {theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
        </button>
      </header>
      <button type="button" onClick={() => { setDraft(profile); setEdit(true); }} className="flex w-full items-center gap-3 px-4 py-4 text-left">
        <span className="grid size-16 place-items-center rounded-full bg-primary-soft text-lg font-bold text-primary">{initials}</span>
        <span className="min-w-0">
          <span className="block text-lg font-bold">{profile.name}</span>
          <span className="block text-sm text-muted">{profile.phone}</span>
          <span className="block truncate text-sm text-muted">{profile.email}</span>
        </span>
      </button>
      <button
        type="button"
        onClick={toggleTheme}
        className="mx-4 mb-2 flex h-12 w-auto items-center justify-between rounded-2xl bg-chip px-3"
      >
        <span className="text-sm font-semibold">Тёмная тема</span>
        <span className={theme === "dark" ? "text-sm font-bold text-primary" : "text-sm text-muted"}>
          {theme === "dark" ? "вкл" : "выкл"}
        </span>
      </button>
      <ul className="px-4">
        {rows.map((row) => {
          const Icon = row.icon;
          return (
            <li key={row.label}>
              <button type="button" onClick={row.go} className="flex h-14 w-full items-center gap-3 border-b border-line text-left">
                <Icon className="size-5 text-muted" />
                <span className="flex-1 font-semibold">{row.label}</span>
                {row.hint ? <span className="text-sm text-primary">{row.hint}</span> : null}
                <ChevronRight className="size-5 text-muted" />
              </button>
            </li>
          );
        })}
      </ul>
      <p className="px-4 py-6 text-sm text-muted">Зерно · Бишкек · кухня на пр. Чуй, 114</p>
      {edit ? (
        <Sheet title="Ваши данные" onClose={() => setEdit(false)}>
          <form
            className="flex flex-col gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              updateProfile({
                name: draft.name.trim() || profile.name,
                phone: draft.phone.trim() || profile.phone,
                email: draft.email.trim() || profile.email,
              });
              setEdit(false);
            }}
          >
            <label className="text-sm font-semibold">
              Имя
              <input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} className="mt-1 h-12 w-full rounded-2xl bg-chip px-3 font-normal outline-none" />
            </label>
            <label className="text-sm font-semibold">
              Телефон
              <input value={draft.phone} onChange={(event) => setDraft({ ...draft, phone: event.target.value })} className="mt-1 h-12 w-full rounded-2xl bg-chip px-3 font-normal outline-none" />
            </label>
            <label className="text-sm font-semibold">
              Почта
              <input value={draft.email} onChange={(event) => setDraft({ ...draft, email: event.target.value })} className="mt-1 h-12 w-full rounded-2xl bg-chip px-3 font-normal outline-none" />
            </label>
            <PrimaryButton type="submit">Сохранить</PrimaryButton>
          </form>
        </Sheet>
      ) : null}
    </div>
  );
}

export function FavoritesScreen() {
  const favorites = useApp((state) => state.favorites);
  const toggle = useApp((state) => state.toggleFavorite);
  const push = useUi((state) => state.push);
  const [tab, setTab] = useState<"goods" | "cafes">("goods");
  const items = PRODUCTS.filter((item) => favorites.includes(item.id));
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Избранное" />
      <div className="grid grid-cols-2 gap-2 px-4 pb-3">
        <button type="button" onClick={() => setTab("goods")} className={tab === "goods" ? "h-10 rounded-full bg-primary text-sm font-bold text-primary-fg" : "h-10 rounded-full bg-chip text-sm font-semibold"}>
          Товары
        </button>
        <button type="button" onClick={() => setTab("cafes")} className={tab === "cafes" ? "h-10 rounded-full bg-primary text-sm font-bold text-primary-fg" : "h-10 rounded-full bg-chip text-sm font-semibold"}>
          Кофейни
        </button>
      </div>
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        {tab === "goods" ? (
          items.length === 0 ? (
            <div className="py-10 text-center">
              <p className="font-bold">Пока пусто</p>
              <p className="mt-1 text-sm text-muted">Сердечко на карточке сохранит напиток здесь.</p>
            </div>
          ) : (
            <ul className="flex flex-col gap-2">
              {items.map((item) => (
                <li key={item.id} className="flex items-center gap-3 rounded-3xl bg-surface p-2 ring-1 ring-border">
                  <button type="button" onClick={() => push({ kind: "product", productId: item.id })} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                    <Photo src={item.image} alt="" className="size-16 rounded-2xl" />
                    <span>
                      <span className="block font-semibold">{item.name}</span>
                      <span className="block text-sm text-muted">{som(item.price)}</span>
                    </span>
                  </button>
                  <button type="button" aria-label="Убрать" onClick={() => toggle(item.id)} className="grid size-11 place-items-center">
                    <Heart className="size-5 fill-primary text-primary" />
                  </button>
                </li>
              ))}
            </ul>
          )
        ) : (
          <ul className="flex flex-col gap-2">
            {CAFES.map((cafe) => (
              <li key={cafe.id} className="rounded-3xl bg-surface p-4 ring-1 ring-border">
                <p className="font-bold">{cafe.name}</p>
                <p className="text-sm text-muted">{cafe.address}</p>
                <p className="text-sm text-muted">{cafe.hours} · {cafe.km}</p>
                <button type="button" onClick={() => push({ kind: "map", orderId: null })} className="mt-2 text-sm font-bold text-primary">
                  На карте
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export function PromosScreen() {
  const bonuses = useApp((state) => state.bonuses);
  const claimGift = useApp((state) => state.claimGift);
  const applyPromo = useApp((state) => state.applyPromo);
  const push = useUi((state) => state.push);
  const showToast = useUi((state) => state.showToast);
  const progress = Math.min(100, Math.round((bonuses / 500) * 100));
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Акции" />
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-6">
        <button
          type="button"
          onClick={() => push({ kind: "product", productId: "combo-sweet" })}
          className="relative block h-40 w-full overflow-hidden rounded-3xl text-left text-cream"
        >
          <img src="/menu/hero.jpg" alt="" className="absolute inset-0 size-full object-cover" />
          <div className="hero-shade absolute inset-0" />
          <span className="relative flex h-full flex-col justify-end p-4">
            <span className="font-display text-3xl leading-none font-semibold">Кофе и круассан</span>
            <span className="mt-1 text-sm">Сладкая пауза — {som(220)}</span>
          </span>
        </button>
        <article className="mt-4 rounded-3xl bg-surface p-4 ring-1 ring-border">
          <div className="flex items-center justify-between">
            <h2 className="font-bold">Бонусная программа</h2>
            <Gift className="size-5 text-star" />
          </div>
          <p className="mt-1 text-sm text-muted">5% с заказа возвращаются баллами. 500 баллов — капучино.</p>
          <p className="mt-3 text-2xl font-bold">{bonuses} баллов</p>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-chip">
            <div className="h-full rounded-full bg-primary" style={{ width: `${progress}%` }} />
          </div>
          <div className="mt-3">
            <PrimaryButton
              disabled={bonuses < 500}
              onClick={() => {
                if (!claimGift()) {
                  showToast("Нужно 500 баллов");
                  return;
                }
                showToast("Капучино добавлен за баллы");
                push({ kind: "cart" });
              }}
            >
              {bonuses >= 500 ? "Забрать капучино" : `Ещё ${500 - bonuses} до капучино`}
            </PrimaryButton>
          </div>
        </article>
        <ul className="mt-4 flex flex-col gap-2">
          {[
            ["ZERNO20", "−20% на всю корзину"],
            ["SWEET50", "−50 с на заказ"],
          ].map(([code, text]) => (
            <li key={code}>
              <button
                type="button"
                onClick={() => {
                  applyPromo(code);
                  showToast(`${code} применён в корзине`);
                  push({ kind: "cart" });
                }}
                className="flex h-16 w-full items-center justify-between rounded-2xl bg-surface px-3 text-left ring-1 ring-border"
              >
                <span>
                  <span className="block font-bold">{code}</span>
                  <span className="block text-sm text-muted">{text}</span>
                </span>
                <span className="text-sm font-bold text-primary">Применить</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function NotesScreen() {
  const notes = useApp((state) => state.notes);
  const markNotesRead = useApp((state) => state.markNotesRead);
  useEffect(() => {
    markNotesRead();
  }, [markNotesRead]);
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Уведомления" />
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <ul className="flex flex-col gap-2">
          {notes.map((note) => (
            <li key={note.id} className="rounded-3xl bg-surface p-3 ring-1 ring-border">
              <p className="text-sm font-bold">{note.title}</p>
              <p className="mt-1 text-sm text-muted">{note.body}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function SupportScreen() {
  const thread = useApp((state) => state.support);
  const sendSupport = useApp((state) => state.sendSupport);
  const showToast = useUi((state) => state.showToast);
  const [open, setOpen] = useState<string | null>(FAQ[0]?.q ?? null);
  const [chat, setChat] = useState(false);
  const [text, setText] = useState("");
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Поддержка" />
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-6">
        <h2 className="mb-2 text-sm font-bold text-muted">Частые вопросы</h2>
        <ul className="flex flex-col gap-2">
          {FAQ.map((item) => (
            <li key={item.q} className="rounded-2xl bg-surface ring-1 ring-border">
              <button type="button" onClick={() => setOpen((value) => (value === item.q ? null : item.q))} className="flex min-h-12 w-full items-center justify-between px-3 text-left text-sm font-semibold">
                {item.q}
                <ChevronRight className={open === item.q ? "size-4 rotate-90" : "size-4"} />
              </button>
              {open === item.q ? <p className="px-3 pb-3 text-sm text-muted">{item.a}</p> : null}
            </li>
          ))}
        </ul>
        <div className="mt-4 flex flex-col gap-2">
          <button type="button" onClick={() => setChat(true)} className="flex h-14 items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border">
            <MessageSquare className="size-5 text-primary" />
            <span className="font-semibold">Написать в поддержку</span>
          </button>
          <button type="button" onClick={() => showToast("Звоним на +996 312 90 00 20")} className="flex h-14 items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border">
            <Phone className="size-5 text-primary" />
            <span className="font-semibold">Позвонить</span>
          </button>
        </div>
      </div>
      {chat ? (
        <Sheet title="Поддержка" onClose={() => setChat(false)}>
          <Thread
            items={thread}
            mineLabel="Вы"
            themLabel="Поддержка"
            value={text}
            onChange={setText}
            onSend={() => {
              sendSupport(text);
              setText("");
            }}
          />
        </Sheet>
      ) : null}
    </div>
  );
}

export function AddressesScreen() {
  const addresses = useApp((state) => state.addresses);
  const addressId = useApp((state) => state.addressId);
  const setAddress = useApp((state) => state.setAddress);
  const addAddress = useApp((state) => state.addAddress);
  const [text, setText] = useState("");
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Адреса" />
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <ul>
          {addresses.map((item) => (
            <li key={item.id}>
              <button type="button" onClick={() => setAddress(item.id)} className="flex h-16 w-full items-center justify-between border-b border-line text-left">
                <span>
                  <span className="block font-semibold">{item.label}</span>
                  <span className="block text-sm text-muted">{item.text}</span>
                </span>
                <span className={item.id === addressId ? "size-3 rounded-full bg-primary" : "size-3 rounded-full ring-1 ring-border"} />
              </button>
            </li>
          ))}
        </ul>
        <form
          className="mt-4 flex flex-col gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            addAddress(text);
            setText("");
          }}
        >
          <input
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder="Новый адрес, подъезд, квартира"
            className="h-12 rounded-2xl bg-chip px-3 text-sm outline-none"
          />
          <PrimaryButton type="submit" disabled={!text.trim()}>Добавить адрес</PrimaryButton>
        </form>
      </div>
    </div>
  );
}

export function PaymentsScreen() {
  const payment = useApp((state) => state.payment);
  const setPayment = useApp((state) => state.setPayment);
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Оплата" />
      <ul className="px-4">
        {PAYMENTS.map((item) => (
          <li key={item.id}>
            <button
              type="button"
              onClick={() => setPayment(item.id as PaymentId)}
              className="flex h-14 w-full items-center justify-between border-b border-line text-left"
            >
              <span className="font-semibold">{item.name}</span>
              <span className={payment === item.id ? "size-3 rounded-full bg-primary" : "size-3 rounded-full ring-1 ring-border"} />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
