import { useMemo, useState } from "react";
import {
  Bell,
  ChevronDown,
  ChevronRight,
  Clock,
  Heart,
  MapPin,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import {
  ADDONS,
  CITIES,
  ETAS,
  PAYMENTS,
  addonById,
  itemsLabel,
  productById,
  productsFor,
  promoDiscount,
  som,
  type CatalogMode,
  type Tag,
} from "@/lib/zerno/data";
import { useUi } from "@/lib/zerno/nav";
import { cartSubtotal, cartUnit, useApp, type CartLine } from "@/lib/zerno/store";
import { BackBar, CatIcon, IconButton, Photo, PrimaryButton, Qty, Sheet, Stars, Wordmark } from "@/components/zerno/parts";

export function Splash() {
  const enter = useApp((state) => state.enter);
  const reset = useUi((state) => state.reset);
  return (
    <section className="relative h-full overflow-hidden bg-ink text-cream">
      <img src="/menu/hero.jpg" alt="Чёрная чашка латте на кофейных зёрнах" className="absolute inset-0 size-full object-cover" />
      <div className="splash-shade absolute inset-0" />
      <div className="relative flex h-full flex-col items-center justify-between px-6 py-10 text-center">
        <div className="pt-6">
          <div className="flex justify-center">
            <Wordmark light />
          </div>
          <p className="mt-3 text-base">Свежий кофе. Без очереди.</p>
        </div>
        <div className="w-full">
          <PrimaryButton
            onClick={() => {
              enter();
              reset({ kind: "home" });
            }}
          >
            Начать
          </PrimaryButton>
          <p className="mt-3 text-sm opacity-80">Бишкек · кухня на Чуй · 07:00–23:00</p>
        </div>
      </div>
    </section>
  );
}

export function Home() {
  const city = useApp((state) => state.city);
  const setCity = useApp((state) => state.setCity);
  const notes = useApp((state) => state.notes);
  const orders = useApp((state) => state.orders);
  const push = useUi((state) => state.push);
  const [cities, setCities] = useState(false);
  const unread = notes.some((note) => !note.read);
  const current = orders.find((order) => order.status !== "delivered");
  const popular = productsFor("popular");

  const cats: { name: "coffee" | "cold" | "signature" | "classic" | "bakery" | "combo" | "favorites" | "promos"; label: string; go: () => void }[] = [
    { name: "coffee", label: "Кофе", go: () => push({ kind: "catalog", mode: "coffee", title: "Кофе" }) },
    { name: "cold", label: "Холодные", go: () => push({ kind: "catalog", mode: "cold", title: "Холодные" }) },
    { name: "signature", label: "Авторские", go: () => push({ kind: "catalog", mode: "signature", title: "Авторские" }) },
    { name: "classic", label: "Классика", go: () => push({ kind: "catalog", mode: "classic", title: "Классика" }) },
    { name: "bakery", label: "Выпечка", go: () => push({ kind: "catalog", mode: "bakery", title: "Выпечка" }) },
    { name: "combo", label: "Комбо", go: () => push({ kind: "catalog", mode: "combo", title: "Комбо" }) },
    { name: "favorites", label: "Избранное", go: () => push({ kind: "favorites" }) },
    { name: "promos", label: "Акции", go: () => push({ kind: "promos" }) },
  ];

  return (
    <div className="app-scroll h-full overflow-y-auto">
      <header className="flex items-center gap-2 px-4 pt-4">
        <Wordmark compact />
        <div className="ml-auto flex">
          <IconButton label="Поиск" onClick={() => push({ kind: "search" })}>
            <Search className="size-5" />
          </IconButton>
          <IconButton label="Уведомления" dot={unread} onClick={() => push({ kind: "notifications" })}>
            <Bell className="size-5" />
          </IconButton>
        </div>
      </header>
      <div className="flex items-center pr-2">
        <button type="button" onClick={() => setCities(true)} className="flex items-center gap-2 px-4 py-2 text-sm">
          <MapPin className="size-4 text-primary" />
          <span className="text-muted">Ваш город</span>
          <span className="font-semibold">{city}</span>
          <ChevronDown className="size-4 text-muted" />
        </button>
        <button
          type="button"
          onClick={() => push({ kind: "map", orderId: current?.id ?? null })}
          className="ml-auto h-11 rounded-full px-3 text-sm font-bold text-primary"
        >
          Карта
        </button>
      </div>

      <div className="px-4">
        <button
          type="button"
          onClick={() => push({ kind: "catalog", mode: "coffee", title: "Кофе" })}
          className="relative block h-44 w-full overflow-hidden rounded-3xl text-left text-cream"
        >
          <img src="/menu/hero.jpg" alt="" className="absolute inset-0 size-full object-cover" />
          <div className="hero-shade absolute inset-0" />
          <div className="relative flex h-full flex-col justify-end p-4">
            <p className="font-display text-3xl leading-none font-semibold">Ароматный кофе</p>
            <p className="mt-1 max-w-56 text-sm">День начинается с чашки, а не с очереди.</p>
            <span className="mt-3 inline-flex h-10 w-fit items-center rounded-full bg-cream px-4 text-sm font-bold text-ink">
              Заказать
            </span>
          </div>
        </button>
      </div>

      <div className="grid grid-cols-4 gap-2 px-4 py-4">
        {cats.map((cat) => (
          <button key={cat.name} type="button" onClick={cat.go} className="flex flex-col items-center gap-1.5 py-1">
            <span className="grid size-14 place-items-center rounded-2xl bg-primary-soft text-primary">
              <CatIcon name={cat.name} />
            </span>
            <span className="text-xs font-semibold">{cat.label}</span>
          </button>
        ))}
      </div>

      {current ? (
        <button
          type="button"
          onClick={() => push({ kind: "order", orderId: current.id })}
          className="mx-4 mb-4 flex items-center gap-3 rounded-3xl bg-surface p-3 text-left ring-1 ring-border"
        >
          <span className="grid size-12 place-items-center rounded-2xl bg-primary-soft text-primary">
            <Clock className="size-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-sm font-bold">Заказ #{current.id}</span>
            <span className="block truncate text-sm text-muted">
              {current.status === "accepted"
                ? "Принят"
                : current.status === "cooking"
                  ? "Готовится"
                  : "Курьер в пути"}
            </span>
          </span>
          <ChevronRight className="size-5 text-muted" />
        </button>
      ) : null}

      <div className="mb-2 flex items-center justify-between px-4">
        <h2 className="text-lg font-bold">Популярное</h2>
        <button
          type="button"
          onClick={() => push({ kind: "catalog", mode: "popular", title: "Популярное" })}
          className="text-sm font-semibold text-primary"
        >
          Все
        </button>
      </div>
      <div className="flex gap-3 overflow-x-auto px-4 pb-6">
        {popular.map((item) => (
          <article key={item.id} className="w-40 shrink-0 overflow-hidden rounded-3xl bg-surface ring-1 ring-border">
            <button type="button" onClick={() => push({ kind: "product", productId: item.id })} className="block w-full text-left">
              <Photo src={item.image} alt={item.name} className="h-28 w-full" />
              <div className="px-3 pt-2">
                <p className="font-semibold">{item.name}</p>
                <p className="text-xs text-muted">{item.volume}</p>
              </div>
            </button>
            <div className="flex items-center justify-between px-3 pb-3">
              <span className="text-sm font-bold">{som(item.price)}</span>
              <AddDot productId={item.id} />
            </div>
          </article>
        ))}
      </div>

      {cities ? (
        <Sheet title="Город" onClose={() => setCities(false)}>
          {CITIES.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => {
                setCity(name);
                setCities(false);
              }}
              className="flex h-12 w-full items-center justify-between border-b border-line text-left font-semibold"
            >
              {name}
              {city === name ? <span className="text-sm text-primary">выбран</span> : null}
            </button>
          ))}
        </Sheet>
      ) : null}
    </div>
  );
}

const CHIPS: { id: "all" | Tag; label: string }[] = [
  { id: "all", label: "Все" },
  { id: "classic", label: "Классика" },
  { id: "signature", label: "Авторские" },
  { id: "cold", label: "Холодные" },
];

export function Catalog({ mode, title }: { mode: CatalogMode; title: string }) {
  const push = useUi((state) => state.push);
  const [chip, setChip] = useState<(typeof CHIPS)[number]["id"]>("all");
  const showChips = mode === "all" || mode === "coffee" || mode === "popular";
  const items = useMemo(() => {
    const base = productsFor(mode);
    if (!showChips || chip === "all") return base;
    return base.filter((item) => item.tags.includes(chip));
  }, [mode, chip, showChips]);

  return (
    <div className="flex h-full flex-col">
      <BackBar
        title={title}
        extra={
          <IconButton label="Поиск" onClick={() => push({ kind: "search" })}>
            <Search className="size-5" />
          </IconButton>
        }
      />
      {showChips ? (
        <div className="flex gap-2 overflow-x-auto px-4 pb-3">
          {CHIPS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setChip(item.id)}
              className={
                chip === item.id
                  ? "h-9 shrink-0 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg"
                  : "h-9 shrink-0 rounded-full bg-chip px-4 text-sm font-semibold"
              }
            >
              {item.label}
            </button>
          ))}
        </div>
      ) : null}
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        {items.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">В этом разделе пока пусто.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {items.map((item) => (
              <li key={item.id} className="flex items-center gap-3 rounded-3xl bg-surface p-2 ring-1 ring-border">
                <button
                  type="button"
                  onClick={() => push({ kind: "product", productId: item.id })}
                  className="flex min-w-0 flex-1 items-center gap-3 text-left"
                >
                  <Photo src={item.image} alt="" className="size-16 rounded-2xl" />
                  <span className="min-w-0">
                    <span className="block font-semibold">{item.name}</span>
                    <span className="block text-xs text-muted">{item.volume}</span>
                    <span className="mt-1 block text-sm font-bold">{som(item.price)}</span>
                  </span>
                </button>
                <AddDot productId={item.id} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function AddDot({ productId }: { productId: string }) {
  const add = useApp((state) => state.addToCart);
  const showToast = useUi((state) => state.showToast);
  const name = productById(productId)?.name ?? "Позиция";
  return (
    <button
      type="button"
      aria-label={`Добавить ${name}`}
      onClick={() => {
        add(productId, []);
        showToast(`${name} в корзине`);
      }}
      className="grid size-11 shrink-0 place-items-center rounded-full bg-primary text-primary-fg"
    >
      <Plus className="size-5" />
    </button>
  );
}

export function ProductView({ id }: { id: string }) {
  const product = productById(id);
  const back = useUi((state) => state.back);
  const add = useApp((state) => state.addToCart);
  const favorites = useApp((state) => state.favorites);
  const toggleFavorite = useApp((state) => state.toggleFavorite);
  const showToast = useUi((state) => state.showToast);
  const [qty, setQty] = useState(1);
  const [addons, setAddons] = useState<string[]>([]);
  if (!product) {
    return (
      <div className="p-6">
        <p>Такого напитка нет.</p>
        <button type="button" onClick={back} className="mt-3 font-semibold text-primary">
          Назад
        </button>
      </div>
    );
  }
  const extra = addons.reduce((sum, addonId) => sum + (addonById(addonId)?.price ?? 0), 0);
  const loved = favorites.includes(product.id);
  return (
    <div className="flex h-full flex-col">
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto">
        <div className="relative h-72">
          <Photo src={product.image} alt={product.name} className="size-full" />
          <button
            type="button"
            aria-label="Назад"
            onClick={back}
            className="absolute top-3 left-3 grid size-11 place-items-center rounded-full bg-surface text-fg"
          >
            <ChevronDown className="size-6 -rotate-90" />
          </button>
          <button
            type="button"
            aria-label={loved ? "Убрать из избранного" : "В избранное"}
            onClick={() => toggleFavorite(product.id)}
            className="absolute top-3 right-3 grid size-11 place-items-center rounded-full bg-surface"
          >
            <Heart className={loved ? "size-5 fill-primary text-primary" : "size-5"} />
          </button>
        </div>
        <div className="px-4 py-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold">{product.name}</h1>
              <p className="text-sm text-muted">{product.volume}</p>
            </div>
            <p className="text-xl font-bold">{som(product.price + extra)}</p>
          </div>
          <p className="mt-2 flex items-center gap-2 text-sm text-muted">
            <Stars value={product.rating} />
            <span>{product.reviews} отзывов</span>
          </p>
          <p className="mt-3 text-sm leading-relaxed">{product.desc}</p>
          <h2 className="mt-5 mb-2 font-bold">Добавки</h2>
          <ul className="flex flex-col gap-2">
            {ADDONS.map((addon) => {
              const on = addons.includes(addon.id);
              return (
                <li key={addon.id}>
                  <button
                    type="button"
                    onClick={() =>
                      setAddons((current) =>
                        current.includes(addon.id) ? current.filter((item) => item !== addon.id) : [...current, addon.id],
                      )
                    }
                    className="flex h-12 w-full items-center justify-between rounded-2xl bg-surface px-3 text-left ring-1 ring-border"
                  >
                    <span className="text-sm font-semibold">{addon.name}</span>
                    <span className="text-sm font-semibold text-muted">+{som(addon.price)}</span>
                    <span
                      className={
                        on
                          ? "grid size-6 place-items-center rounded-full bg-primary text-xs font-bold text-primary-fg"
                          : "size-6 rounded-full ring-1 ring-border"
                      }
                      aria-hidden="true"
                    >
                      {on ? "✓" : ""}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-3 border-t border-border bg-bg px-4 py-3">
        <Qty value={qty} onDec={() => setQty((value) => Math.max(1, value - 1))} onInc={() => setQty((value) => value + 1)} />
        <div className="min-w-0 flex-1">
          <PrimaryButton
            onClick={() => {
              add(product.id, addons, qty);
              showToast(`${product.name} в корзине`);
            }}
          >
            В корзину · {som((product.price + extra) * qty)}
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
}

export function SearchScreen() {
  const push = useUi((state) => state.push);
  const [query, setQuery] = useState("");
  const items = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return productsFor("all");
    return productsFor("all").filter(
      (item) => item.name.toLowerCase().includes(needle) || item.desc.toLowerCase().includes(needle),
    );
  }, [query]);
  return (
    <div className="flex h-full flex-col">
      <BackBar title="Поиск" />
      <div className="px-4 pb-3">
        <label className="flex h-12 items-center gap-2 rounded-2xl bg-chip px-3">
          <Search className="size-4 text-muted" />
          <input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Латте, круассан, матча"
            className="h-full w-full bg-transparent text-sm outline-none"
          />
        </label>
      </div>
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <ul className="flex flex-col gap-2">
          {items.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => push({ kind: "product", productId: item.id })}
                className="flex w-full items-center gap-3 rounded-3xl bg-surface p-2 text-left ring-1 ring-border"
              >
                <Photo src={item.image} alt="" className="size-14 rounded-2xl" />
                <span className="min-w-0 flex-1">
                  <span className="block font-semibold">{item.name}</span>
                  <span className="block text-sm text-muted">{som(item.price)}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
        {items.length === 0 ? <p className="py-8 text-center text-sm text-muted">Ничего не нашли. Попробуйте «латте».</p> : null}
      </div>
    </div>
  );
}

export function CartScreen() {
  const cart = useApp((state) => state.cart);
  const promo = useApp((state) => state.promo);
  const setQty = useApp((state) => state.setQty);
  const clearCart = useApp((state) => state.clearCart);
  const applyPromo = useApp((state) => state.applyPromo);
  const clearPromo = useApp((state) => state.clearPromo);
  const push = useUi((state) => state.push);
  const showToast = useUi((state) => state.showToast);
  const [code, setCode] = useState("");
  const subtotal = cartSubtotal(cart);
  const discount = promoDiscount(promo, subtotal);
  const total = Math.max(0, subtotal - discount);

  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 items-center justify-between px-4">
        <h1 className="text-lg font-bold">Корзина</h1>
        {cart.length > 0 ? (
          <button type="button" onClick={clearCart} className="text-sm font-semibold text-primary">
            Очистить
          </button>
        ) : null}
      </header>
      {cart.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <Photo src="/menu/latte.jpg" alt="" className="size-28 rounded-full" />
          <p className="mt-4 text-lg font-bold">Корзина пуста</p>
          <p className="mt-1 text-sm text-muted">Латте, раф или круассан — кухня на Чуй уже открыта.</p>
          <div className="mt-5 w-full">
            <PrimaryButton onClick={() => push({ kind: "catalog", mode: "coffee", title: "Кофе" })}>К кофе</PrimaryButton>
          </div>
        </div>
      ) : (
        <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
          <ul className="flex flex-col gap-2">
            {cart.map((line) => (
              <CartRow key={line.key} line={line} onQty={(qty) => setQty(line.key, qty)} />
            ))}
          </ul>
          <form
            className="mt-4 flex gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              const ok = applyPromo(code);
              showToast(ok ? `Промокод ${code.trim().toUpperCase()} применён` : "Такого промокода нет");
              if (ok) setCode("");
            }}
          >
            <input
              value={code}
              onChange={(event) => setCode(event.target.value)}
              placeholder="Промокод"
              className="h-12 min-w-0 flex-1 rounded-2xl bg-chip px-4 text-sm outline-none"
            />
            <button type="submit" className="h-12 rounded-2xl bg-chip px-4 text-sm font-bold">
              Ок
            </button>
          </form>
          {promo ? (
            <p className="mt-2 flex items-center justify-between text-sm">
              <span>
                {promo} · −{som(discount)}
              </span>
              <button type="button" onClick={clearPromo} className="font-semibold text-primary">
                Убрать
              </button>
            </p>
          ) : (
            <p className="mt-2 text-xs text-muted">Попробуйте ZERNO20 или SWEET50</p>
          )}
          <div className="mt-4 flex items-center justify-between">
            <span className="text-muted">{itemsLabel(cart.reduce((sum, line) => sum + line.qty, 0))}</span>
            <span className="text-xl font-bold">{som(total)}</span>
          </div>
          <div className="mt-3">
            <PrimaryButton onClick={() => push({ kind: "checkout" })}>Оформить заказ</PrimaryButton>
          </div>
          <button type="button" onClick={clearCart} className="mx-auto mt-3 flex items-center gap-1 text-sm text-muted">
            <Trash2 className="size-4" />
            Очистить корзину
          </button>
        </div>
      )}
    </div>
  );
}

function CartRow({ line, onQty }: { line: CartLine; onQty: (qty: number) => void }) {
  const product = productById(line.productId);
  if (!product) return null;
  const addonNames = line.addonIds.map((id) => addonById(id)?.name).filter(Boolean);
  return (
    <li className="flex items-center gap-3 rounded-3xl bg-surface p-2 ring-1 ring-border">
      <Photo src={product.image} alt="" className="size-16 rounded-2xl" />
      <div className="min-w-0 flex-1">
        <p className="font-semibold">{product.name}</p>
        <p className="truncate text-xs text-muted">
          {product.volume}
          {addonNames.length ? ` · ${addonNames.join(", ")}` : ""}
          {line.priceOverride === 0 ? " · за баллы" : ""}
        </p>
        <p className="text-sm font-bold">{som(cartUnit(line) * line.qty)}</p>
      </div>
      <Qty value={line.qty} onDec={() => onQty(line.qty - 1)} onInc={() => onQty(line.qty + 1)} />
    </li>
  );
}

export function Checkout() {
  const cart = useApp((state) => state.cart);
  const promo = useApp((state) => state.promo);
  const bonuses = useApp((state) => state.bonuses);
  const addresses = useApp((state) => state.addresses);
  const addressId = useApp((state) => state.addressId);
  const setAddress = useApp((state) => state.setAddress);
  const payment = useApp((state) => state.payment);
  const setPayment = useApp((state) => state.setPayment);
  const placeOrder = useApp((state) => state.placeOrder);
  const reset = useUi((state) => state.reset);
  const showToast = useUi((state) => state.showToast);
  const [mode, setMode] = useState<"delivery" | "pickup">("delivery");
  const [eta, setEta] = useState(ETAS[0]);
  const [comment, setComment] = useState("");
  const [useBonus, setUseBonus] = useState(false);
  const [pickAddress, setPickAddress] = useState(false);
  const [pickEta, setPickEta] = useState(false);
  const subtotal = cartSubtotal(cart);
  const discount = promoDiscount(promo, subtotal);
  const after = Math.max(0, subtotal - discount);
  const bonusSpend = useBonus ? Math.min(bonuses, Math.floor(after * 0.3)) : 0;
  const total = after - bonusSpend;
  const address = addresses.find((item) => item.id === addressId) ?? addresses[0];

  return (
    <div className="flex h-full flex-col">
      <BackBar title="Оформление" />
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <div className="grid grid-cols-2 gap-2 rounded-full bg-chip p-1">
          {(
            [
              ["delivery", "Доставка"],
              ["pickup", "Самовывоз"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setMode(id)}
              className={
                mode === id
                  ? "h-10 rounded-full bg-primary text-sm font-bold text-primary-fg"
                  : "h-10 rounded-full text-sm font-semibold"
              }
            >
              {label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => (mode === "delivery" ? setPickAddress(true) : undefined)}
          className="mt-4 flex h-14 w-full items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border"
        >
          <MapPin className="size-5 shrink-0 text-primary" />
          <span className="min-w-0 flex-1">
            <span className="block text-xs text-muted">{mode === "delivery" ? "Адрес доставки" : "Кафе"}</span>
            <span className="block truncate text-sm font-semibold">
              {mode === "delivery" ? address?.text : "пр. Чуй, 114 — Зерно"}
            </span>
          </span>
          {mode === "delivery" ? <ChevronRight className="size-5 text-muted" /> : null}
        </button>

        <button
          type="button"
          onClick={() => setPickEta(true)}
          className="mt-2 flex h-14 w-full items-center gap-3 rounded-2xl bg-surface px-3 text-left ring-1 ring-border"
        >
          <Clock className="size-5 text-primary" />
          <span className="min-w-0 flex-1">
            <span className="block text-xs text-muted">Время</span>
            <span className="block text-sm font-semibold">{eta}</span>
          </span>
          <ChevronRight className="size-5 text-muted" />
        </button>

        <label className="mt-4 block text-sm font-semibold">
          Комментарий
          <textarea
            value={comment}
            onChange={(event) => setComment(event.target.value)}
            placeholder="Например: без сиропа, позвоните у подъезда"
            className="mt-2 h-24 w-full resize-none rounded-2xl bg-chip p-3 text-sm font-normal outline-none"
          />
        </label>

        <h2 className="mt-4 mb-2 font-bold">Оплата</h2>
        <ul className="flex flex-col gap-2">
          {PAYMENTS.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => setPayment(item.id)}
                className="flex h-12 w-full items-center justify-between rounded-2xl bg-surface px-3 ring-1 ring-border"
              >
                <span className="text-sm font-semibold">{item.name}</span>
                <span className={payment === item.id ? "size-3 rounded-full bg-primary" : "size-3 rounded-full ring-1 ring-border"} />
              </button>
            </li>
          ))}
        </ul>

        <button
          type="button"
          onClick={() => setUseBonus((value) => !value)}
          className="mt-3 flex h-12 w-full items-center justify-between rounded-2xl bg-surface px-3 ring-1 ring-border"
        >
          <span className="text-sm font-semibold">Списать баллы · {bonuses}</span>
          <span className={useBonus ? "text-sm font-bold text-primary" : "text-sm text-muted"}>
            {useBonus ? `−${som(bonusSpend)}` : "выкл"}
          </span>
        </button>

        <div className="mt-4 flex items-center justify-between">
          <span className="text-muted">Итого</span>
          <span className="text-xl font-bold">{som(total)}</span>
        </div>
        <div className="mt-3">
          <PrimaryButton
            disabled={cart.length === 0}
            onClick={() => {
              const id = placeOrder({ mode, eta, comment, bonusSpend, total });
              if (!id) {
                showToast("Корзина пуста");
                return;
              }
              showToast(`Заказ #${id} принят`);
              reset({ kind: "order", orderId: id });
            }}
          >
            Оплатить {som(total)}
          </PrimaryButton>
        </div>
      </div>

      {pickAddress ? (
        <Sheet title="Адрес" onClose={() => setPickAddress(false)}>
          {addresses.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setAddress(item.id);
                setPickAddress(false);
              }}
              className="flex h-14 w-full flex-col items-start justify-center border-b border-line text-left"
            >
              <span className="text-sm font-bold">{item.label}</span>
              <span className="text-xs text-muted">{item.text}</span>
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              setPickAddress(false);
              useUi.getState().push({ kind: "addresses" });
            }}
            className="mt-3 h-11 text-sm font-semibold text-primary"
          >
            Новый адрес
          </button>
        </Sheet>
      ) : null}

      {pickEta ? (
        <Sheet title="Когда привезти" onClose={() => setPickEta(false)}>
          {ETAS.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => {
                setEta(item);
                setPickEta(false);
              }}
              className="flex h-12 w-full items-center border-b border-line text-left font-semibold"
            >
              {item}
            </button>
          ))}
        </Sheet>
      ) : null}
    </div>
  );
}
