import { createContext, useContext, type ReactNode } from "react";
import {
  BadgePercent,
  ChevronLeft,
  Coffee,
  Croissant,
  CupSoda,
  GlassWater,
  Heart,
  Home,
  Layers,
  Minus,
  Plus,
  ShoppingBag,
  Sparkles,
  Star,
  User,
  X,
} from "lucide-react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/cn";
import { cartCount, useApp } from "@/lib/zerno/store";
import { useScreen, useUi, type Screen } from "@/lib/zerno/nav";

export function BeanMark() {
  return (
    <svg viewBox="0 0 24 24" className="size-5" aria-hidden="true">
      <ellipse cx="12" cy="12" rx="5.5" ry="8.5" fill="currentColor" />
      <path
        d="M12 5c1.1 2.2 1.1 4.4 0 14"
        fill="none"
        stroke="var(--color-primary)"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Wordmark({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2", light ? "text-cream" : "text-fg")}>
      <span className="grid size-9 shrink-0 place-items-center rounded-full bg-primary text-primary-fg">
        <BeanMark />
      </span>
      <span className={cn("font-display leading-none font-semibold", compact ? "text-2xl" : "text-4xl")}>
        Зерно
      </span>
    </div>
  );
}

export function Photo({ src, alt, className }: { src: string; alt: string; className?: string }) {
  return <img src={src} alt={alt} className={cn("bg-chip object-cover", className)} />;
}

export function IconButton({
  label,
  onClick,
  children,
  dot = false,
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
  dot?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="relative grid size-11 place-items-center rounded-full text-fg"
    >
      {children}
      {dot ? <span className="absolute top-2 right-2 size-2 rounded-full bg-primary" /> : null}
    </button>
  );
}

export function BackBar({ title, extra }: { title: string; extra?: ReactNode }) {
  const back = useUi((state) => state.back);
  const depth = useUi((state) => state.stack.length);
  return (
    <header className="flex h-14 shrink-0 items-center gap-1 px-1">
      {depth > 1 ? (
        <button type="button" aria-label="Назад" onClick={back} className="grid size-11 place-items-center rounded-full">
          <ChevronLeft className="size-6" />
        </button>
      ) : (
        <span className="w-3" />
      )}
      <h1 className="min-w-0 flex-1 truncate text-lg font-bold">{title}</h1>
      {extra}
    </header>
  );
}

export function PrimaryButton({
  children,
  onClick,
  disabled = false,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className="flex h-12 w-full items-center justify-center rounded-full bg-primary px-4 text-base font-bold text-primary-fg disabled:opacity-40"
    >
      {children}
    </button>
  );
}

export function Qty({
  value,
  onDec,
  onInc,
}: {
  value: number;
  onDec: () => void;
  onInc: () => void;
}) {
  return (
    <div className="flex items-center">
      <button type="button" aria-label="Меньше" onClick={onDec} className="grid size-11 place-items-center rounded-full bg-chip">
        <Minus className="size-4" />
      </button>
      <span className="w-8 text-center text-sm font-bold">{value}</span>
      <button type="button" aria-label="Больше" onClick={onInc} className="grid size-11 place-items-center rounded-full bg-primary text-primary-fg">
        <Plus className="size-4" />
      </button>
    </div>
  );
}

export function Stars({ value }: { value: number }) {
  return (
    <span className="inline-flex items-center gap-1 text-sm font-semibold">
      <Star className="size-4 fill-star text-star" />
      {value.toFixed(1)}
    </span>
  );
}

export const FrameContext = createContext<HTMLDivElement | null>(null);

export function Sheet({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const frame = useContext(FrameContext);
  const node = (
    <div className="absolute inset-0 z-40 flex flex-col justify-end bg-ink/50" onClick={onClose}>
      <div
        role="dialog"
        aria-label={title}
        className="sheet-body overflow-y-auto rounded-t-3xl bg-surface px-4 pt-3 pb-6"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-border" />
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold">{title}</h2>
          <button type="button" aria-label="Закрыть" onClick={onClose} className="grid size-11 place-items-center">
            <X className="size-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
  if (!frame) return node;
  return createPortal(node, frame);
}

const CAT_ICONS = {
  coffee: Coffee,
  cold: GlassWater,
  signature: Sparkles,
  classic: CupSoda,
  bakery: Croissant,
  combo: Layers,
  favorites: Heart,
  promos: BadgePercent,
} as const;

export function CatIcon({ name }: { name: keyof typeof CAT_ICONS }) {
  const Icon = CAT_ICONS[name];
  return <Icon className="size-6" />;
}

const TABBED = new Set(["home", "catalog", "cart", "profile", "orders"]);

export function showsTabs(kind: Screen["kind"]) {
  return TABBED.has(kind);
}

export function TabBar() {
  const screen = useScreen();
  const reset = useUi((state) => state.reset);
  const count = useApp((state) => cartCount(state.cart));
  const active =
    screen.kind === "catalog"
      ? "catalog"
      : screen.kind === "cart"
        ? "cart"
        : screen.kind === "profile" || screen.kind === "orders"
          ? "profile"
          : "home";

  const tabs: { id: string; label: string; icon: typeof Home; go: () => void }[] = [
    { id: "home", label: "Главная", icon: Home, go: () => reset({ kind: "home" }) },
    {
      id: "catalog",
      label: "Меню",
      icon: Coffee,
      go: () => reset({ kind: "catalog", mode: "all", title: "Меню" }),
    },
    { id: "cart", label: "Корзина", icon: ShoppingBag, go: () => reset({ kind: "cart" }) },
    { id: "profile", label: "Профиль", icon: User, go: () => reset({ kind: "profile" }) },
  ];

  return (
    <nav className="grid shrink-0 grid-cols-4 border-t border-border bg-surface px-1 pt-1 pb-2">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const on = active === tab.id;
        return (
          <button
            key={tab.id}
            type="button"
            onClick={tab.go}
            className={cn("flex flex-col items-center gap-0.5 py-1 text-xs font-semibold", on ? "text-primary" : "text-muted")}
          >
            <span className="relative">
              <Icon className="size-6" />
              {tab.id === "cart" && count > 0 ? (
                <span className="absolute -top-2 -right-3 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-xs leading-none font-bold text-primary-fg">
                  {count}
                </span>
              ) : null}
            </span>
            {tab.label}
          </button>
        );
      })}
    </nav>
  );
}
