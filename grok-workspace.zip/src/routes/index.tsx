import { createFileRoute } from "@tanstack/react-router";
import { ZernoApp } from "@/components/zerno/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ZernoApp />;
}
