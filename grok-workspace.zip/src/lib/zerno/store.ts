import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  CAFE,
  DEFAULT_ADDRESSES,
  type Address,
  type PaymentId,
  productById,
  unitPrice,
} from "@/lib/zerno/data";

export type OrderStatus = "accepted" | "cooking" | "enroute" | "delivered";

export type CartLine = {
  key: string;
  productId: string;
  qty: number;
  addonIds: string[];
  priceOverride?: number;
};

export type OrderLine = {
  productId: string;
  name: string;
  qty: number;
  unit: number;
  image: string;
};

export type Order = {
  id: string;
  createdAt: number;
  lines: OrderLine[];
  total: number;
  address: string;
  lat: number;
  lng: number;
  mode: "delivery" | "pickup";
  payment: string;
  comment: string;
  eta: string;
  status: OrderStatus;
  history: { status: OrderStatus; at: number }[];
};

export type Note = {
  id: string;
  title: string;
  body: string;
  at: number;
  read: boolean;
  tone: "promo" | "info" | "bonus" | "order";
};

export type ChatMessage = { id: string; from: "me" | "them"; text: string; at: number };

type Profile = { name: string; phone: string; email: string };

type AppState = {
  entered: boolean;
  theme: "light" | "dark";
  city: string;
  cart: CartLine[];
  promo: string | null;
  favorites: string[];
  orders: Order[];
  bonuses: number;
  profile: Profile;
  addresses: Address[];
  addressId: string;
  payment: PaymentId;
  notes: Note[];
  support: ChatMessage[];
  courierChat: ChatMessage[];
  enter: () => void;
  setTheme: (theme: "light" | "dark") => void;
  toggleTheme: () => void;
  setCity: (city: string) => void;
  toggleFavorite: (productId: string) => void;
  addToCart: (productId: string, addonIds: string[], qty?: number, priceOverride?: number) => void;
  setQty: (key: string, qty: number) => void;
  clearCart: () => void;
  applyPromo: (code: string) => boolean;
  clearPromo: () => void;
  setAddress: (id: string) => void;
  addAddress: (text: string) => void;
  setPayment: (id: PaymentId) => void;
  updateProfile: (profile: Profile) => void;
  placeOrder: (input: {
    mode: "delivery" | "pickup";
    eta: string;
    comment: string;
    bonusSpend: number;
    total: number;
  }) => string | null;
  advanceOrders: (now: number) => void;
  markNotesRead: () => void;
  sendSupport: (text: string) => void;
  sendCourier: (text: string) => void;
  claimGift: () => boolean;
  repeatOrder: (orderId: string) => void;
};

const STATUS_FLOW: OrderStatus[] = ["accepted", "cooking", "enroute", "delivered"];

const STAGE_MS: Record<OrderStatus, number> = {
  accepted: 6000,
  cooking: 7000,
  enroute: 22000,
  delivered: Number.POSITIVE_INFINITY,
};

const STATUS_COPY: Record<OrderStatus, [string, string]> = {
  accepted: ["Заказ принят", "Кухня уже видит ваш заказ."],
  cooking: ["Готовится", "Бариста собирает напитки."],
  enroute: ["Курьер в пути", "Тимур выехал. Можно открыть карту."],
  delivered: ["Заказ доставлен", "Приятного кофе. Спасибо, что выбрали Зерно."],
};

function lineKey(productId: string, addonIds: string[], gift = false) {
  const addons = [...addonIds].sort().join(",");
  return gift ? `${productId}:gift` : `${productId}:${addons}`;
}

function seedNow() {
  return Date.now();
}

function makeNote(partial: Omit<Note, "id" | "read"> & { read?: boolean }): Note {
  return { read: false, id: `n-${partial.at}-${partial.title}`, ...partial };
}

const openedAt = seedNow();

function seedOrders(): Order[] {
  const latte = productById("latte");
  const cap = productById("cappuccino");
  const croissant = productById("croissant");
  const iced = productById("iced");
  if (!latte || !cap || !croissant || !iced) return [];
  const home = DEFAULT_ADDRESSES[0];
  const older = openedAt - 1000 * 60 * 60 * 26;
  const newer = openedAt - 1000 * 60 * 60 * 5;
  return [
    {
      id: "45871",
      createdAt: newer,
      lines: [
        { productId: cap.id, name: cap.name, qty: 1, unit: cap.price, image: cap.image },
        { productId: croissant.id, name: croissant.name, qty: 1, unit: croissant.price, image: croissant.image },
      ],
      total: 210,
      address: home.text,
      lat: home.lat,
      lng: home.lng,
      mode: "delivery",
      payment: "Картой онлайн",
      comment: "",
      eta: "30–45 мин",
      status: "delivered",
      history: STATUS_FLOW.map((status, index) => ({ status, at: newer + index * 60_000 })),
    },
    {
      id: "45862",
      createdAt: older,
      lines: [
        { productId: latte.id, name: latte.name, qty: 2, unit: latte.price, image: latte.image },
        { productId: iced.id, name: iced.name, qty: 1, unit: iced.price, image: iced.image },
      ],
      total: 450,
      address: "Самовывоз · пр. Чуй, 114",
      lat: CAFE.lat,
      lng: CAFE.lng,
      mode: "pickup",
      payment: "Наличными курьеру",
      comment: "Без сиропа",
      eta: "15 мин",
      status: "delivered",
      history: STATUS_FLOW.map((status, index) => ({ status, at: older + index * 60_000 })),
    },
  ];
}

export function cartUnit(line: CartLine) {
  if (typeof line.priceOverride === "number") return line.priceOverride;
  return unitPrice(line.productId, line.addonIds);
}

export function cartCount(cart: CartLine[]) {
  return cart.reduce((sum, line) => sum + line.qty, 0);
}

export function cartSubtotal(cart: CartLine[]) {
  return cart.reduce((sum, line) => sum + cartUnit(line) * line.qty, 0);
}

export function activeOrder(orders: Order[]) {
  return orders.find((order) => order.status !== "delivered") ?? null;
}

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      entered: false,
      theme: "light",
      city: "Бишкек",
      cart: [],
      promo: null,
      favorites: ["latte", "raf"],
      orders: seedOrders(),
      bonuses: 320,
      profile: {
        name: "Нурлан Асанов",
        phone: "+996 555 120 334",
        email: "nurlan@zerno.kg",
      },
      addresses: DEFAULT_ADDRESSES,
      addressId: "home",
      payment: "card",
      notes: [
        makeNote({
          title: "Скидка 20% на кофе",
          body: "Промокод ZERNO20 действует сегодня на всю корзину.",
          at: openedAt - 50 * 60_000,
          tone: "promo",
        }),
        makeNote({
          title: "Новое в меню",
          body: "Ванильный раф и матча латте уже можно заказать.",
          at: openedAt - 26 * 60 * 60_000,
          tone: "info",
          read: true,
        }),
        makeNote({
          title: "На счёте 320 баллов",
          body: "До капучино в подарок осталось 180. Копите или списывайте на оплате.",
          at: openedAt - 3 * 24 * 60 * 60_000,
          tone: "bonus",
          read: true,
        }),
      ],
      support: [
        {
          id: "s0",
          from: "them",
          text: "Здравствуйте. Это Зерно. Напишите, если заказ задерживается или напиток приехал не таким.",
          at: openedAt - 60_000,
        },
      ],
      courierChat: [],
      enter: () => set({ entered: true }),
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set({ theme: get().theme === "dark" ? "light" : "dark" }),
      setCity: (city) => set({ city }),
      toggleFavorite: (productId) =>
        set({
          favorites: get().favorites.includes(productId)
            ? get().favorites.filter((id) => id !== productId)
            : [...get().favorites, productId],
        }),
      addToCart: (productId, addonIds, qty = 1, priceOverride) => {
        const key = lineKey(productId, addonIds, typeof priceOverride === "number");
        const cart = get().cart;
        const existing = cart.find((line) => line.key === key);
        if (existing) {
          set({
            cart: cart.map((line) => (line.key === key ? { ...line, qty: line.qty + qty } : line)),
          });
          return;
        }
        set({
          cart: [...cart, { key, productId, qty, addonIds, priceOverride }],
        });
      },
      setQty: (key, qty) =>
        set({
          cart:
            qty <= 0
              ? get().cart.filter((line) => line.key !== key)
              : get().cart.map((line) => (line.key === key ? { ...line, qty } : line)),
        }),
      clearCart: () => set({ cart: [], promo: null }),
      applyPromo: (code) => {
        const normalized = code.trim().toUpperCase();
        if (normalized !== "ZERNO20" && normalized !== "SWEET50") return false;
        set({ promo: normalized });
        return true;
      },
      clearPromo: () => set({ promo: null }),
      setAddress: (id) => set({ addressId: id }),
      addAddress: (text) => {
        const clean = text.trim();
        if (!clean) return;
        const id = `addr-${Date.now()}`;
        const shift = get().addresses.length * 0.0015;
        const next: Address = {
          id,
          label: "Адрес",
          text: clean,
          lat: 42.87 + shift,
          lng: 74.59 + shift,
        };
        set({ addresses: [...get().addresses, next], addressId: id });
      },
      setPayment: (id) => set({ payment: id }),
      updateProfile: (profile) => set({ profile }),
      placeOrder: ({ mode, eta, comment, bonusSpend, total }) => {
        const state = get();
        if (state.cart.length === 0) return null;
        const address =
          mode === "pickup"
            ? state.addresses.find((item) => item.id === state.addressId) ?? state.addresses[0]
            : state.addresses.find((item) => item.id === state.addressId) ?? state.addresses[0];
        const point =
          mode === "pickup"
            ? { text: `Самовывоз · ${CAFE.address}`, lat: CAFE.lat, lng: CAFE.lng }
            : address;
        const now = Date.now();
        const id = String(46000 + Math.floor(Math.random() * 3000));
        const lines: OrderLine[] = state.cart.map((line) => {
          const product = productById(line.productId);
          return {
            productId: line.productId,
            name: product?.name ?? "Позиция",
            qty: line.qty,
            unit: cartUnit(line),
            image: product?.image ?? "/menu/latte.jpg",
          };
        });
        const paymentName =
          state.payment === "card"
            ? "Картой онлайн"
            : state.payment === "cash"
              ? "Наличными курьеру"
              : "Телефоном";
        const order: Order = {
          id,
          createdAt: now,
          lines,
          total,
          address: point.text,
          lat: point.lat,
          lng: point.lng,
          mode,
          payment: paymentName,
          comment: comment.trim(),
          eta,
          status: "accepted",
          history: [{ status: "accepted", at: now }],
        };
        const earned = Math.round(total * 0.05);
        const [title, body] = STATUS_COPY.accepted;
        set({
          orders: [order, ...state.orders].slice(0, 30),
          cart: [],
          promo: null,
          bonuses: Math.max(0, state.bonuses - bonusSpend) + earned,
          notes: [
            { id: `n-${id}-accepted`, title, body: `Заказ #${id}. ${body}`, at: now, read: false, tone: "order" },
            ...state.notes,
          ],
        });
        return id;
      },
      advanceOrders: (now) => {
        const state = get();
        let changed = false;
        const extraNotes: Note[] = [];
        const orders = state.orders.map((order) => {
          if (order.status === "delivered") return order;
          let status: OrderStatus = order.status;
          let history = order.history;
          let cursor = history[history.length - 1]?.at ?? order.createdAt;
          let moved = false;
          while (status !== "delivered" && now - cursor >= STAGE_MS[status]) {
            const index = STATUS_FLOW.indexOf(status);
            const next = STATUS_FLOW[Math.min(STATUS_FLOW.length - 1, index + 1)];
            cursor += STAGE_MS[status];
            status = next;
            history = [...history, { status, at: cursor }];
            const [title, body] = STATUS_COPY[status];
            extraNotes.push({
              id: `n-${order.id}-${status}`,
              title,
              body: `Заказ #${order.id}. ${body}`,
              at: cursor,
              read: false,
              tone: "order",
            });
            moved = true;
            changed = true;
          }
          return moved ? { ...order, status, history } : order;
        });
        if (!changed) return;
        set({ orders, notes: [...extraNotes, ...state.notes].slice(0, 40) });
      },
      markNotesRead: () => set({ notes: get().notes.map((note) => ({ ...note, read: true })) }),
      sendSupport: (text) => {
        const clean = text.trim();
        if (!clean) return;
        const now = Date.now();
        const mine: ChatMessage = { id: `m-${now}`, from: "me", text: clean, at: now };
        const reply: ChatMessage = {
          id: `r-${now}`,
          from: "them",
          text: "Приняли. Если это про текущий заказ — курьер тоже видит комментарий. Ответим здесь.",
          at: now + 1,
        };
        set({ support: [...get().support, mine, reply] });
      },
      sendCourier: (text) => {
        const clean = text.trim();
        if (!clean) return;
        const now = Date.now();
        const lower = clean.toLowerCase();
        let answer = "На связи. Если подъезд закрыт — напишите код, я отмечу.";
        if (lower.includes("где") || lower.includes("скоро")) {
          answer = "Еду к вам. На карте красная метка — это я, не кафе.";
        } else if (lower.includes("код") || lower.includes("домофон")) {
          answer = "Код записал. Поднимусь и напишу, когда буду у двери.";
        }
        const mine: ChatMessage = { id: `c-${now}`, from: "me", text: clean, at: now };
        const reply: ChatMessage = { id: `k-${now}`, from: "them", text: answer, at: now + 1 };
        set({ courierChat: [...get().courierChat, mine, reply] });
      },
      claimGift: () => {
        if (get().bonuses < 500) return false;
        set({ bonuses: get().bonuses - 500 });
        get().addToCart("cappuccino", [], 1, 0);
        return true;
      },
      repeatOrder: (orderId) => {
        const order = get().orders.find((item) => item.id === orderId);
        if (!order) return;
        order.lines.forEach((line) => {
          get().addToCart(line.productId, [], line.qty, line.unit === 0 ? 0 : undefined);
        });
      },
    }),
    {
      name: "zerno-app",
      skipHydration: true,
    },
  ),
);

export function courierPoint(order: Order, now: number) {
  const dest = { lat: order.lat, lng: order.lng };
  const start = { lat: CAFE.lat, lng: CAFE.lng };
  if (order.mode === "pickup") return start;
  if (order.status === "accepted" || order.status === "cooking") return start;
  if (order.status === "delivered") return dest;
  const began = order.history.find((step) => step.status === "enroute")?.at ?? order.createdAt;
  const raw = Math.min(1, Math.max(0, (now - began) / STAGE_MS.enroute));
  const mid = {
    lat: (start.lat + dest.lat) / 2 + 0.002,
    lng: (start.lng + dest.lng) / 2 - 0.002,
  };
  const lerp = (a: { lat: number; lng: number }, b: { lat: number; lng: number }, t: number) => ({
    lat: a.lat + (b.lat - a.lat) * t,
    lng: a.lng + (b.lng - a.lng) * t,
  });
  if (raw < 0.5) return lerp(start, mid, raw / 0.5);
  return lerp(mid, dest, (raw - 0.5) / 0.5);
}

export function etaLeft(order: Order, now: number) {
  if (order.status === "delivered") return "Доставлен";
  if (order.status === "accepted") return "Принят";
  if (order.status === "cooking") return "Готовится";
  if (order.mode === "pickup") return "Можно забирать";
  const began = order.history.find((step) => step.status === "enroute")?.at ?? now;
  const raw = Math.min(1, Math.max(0, (now - began) / STAGE_MS.enroute));
  const mins = Math.max(1, Math.round(24 * (1 - raw)));
  return `${mins} мин`;
}
