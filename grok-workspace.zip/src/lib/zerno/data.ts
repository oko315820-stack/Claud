export type Tag = "classic" | "signature" | "cold";
export type Category = "coffee" | "bakery" | "combo";
export type CatalogMode =
  | "all"
  | "coffee"
  | "cold"
  | "signature"
  | "classic"
  | "bakery"
  | "combo"
  | "popular";

export type Product = {
  id: string;
  name: string;
  category: Category;
  desc: string;
  volume: string;
  price: number;
  image: string;
  rating: number;
  reviews: number;
  tags: Tag[];
  popular?: boolean;
};

export type Addon = { id: string; name: string; price: number };

export const ADDONS: Addon[] = [
  { id: "shot", name: "Доп. эспрессо", price: 20 },
  { id: "vanilla", name: "Ванильный сироп", price: 15 },
  { id: "caramel", name: "Карамельный сироп", price: 15 },
  { id: "oat", name: "Овсяное молоко", price: 25 },
];

export const PRODUCTS: Product[] = [
  {
    id: "espresso",
    name: "Эспрессо",
    category: "coffee",
    desc: "Короткий и плотный, с ореховой горчинкой. Двойной — если попросить в комментарии.",
    volume: "100 мл",
    price: 100,
    image: "/menu/espresso.jpg",
    rating: 4.8,
    reviews: 86,
    tags: ["classic"],
  },
  {
    id: "americano",
    name: "Американо",
    category: "coffee",
    desc: "Эспрессо и горячая вода. Чистый вкус зерна, без молока и лишней сладости.",
    volume: "200 мл",
    price: 110,
    image: "/menu/americano.jpg",
    rating: 4.7,
    reviews: 142,
    tags: ["classic"],
    popular: true,
  },
  {
    id: "cappuccino",
    name: "Капучино",
    category: "coffee",
    desc: "Равные доли эспрессо, молока и пены. Утренний стандарт нашей смены.",
    volume: "250 мл",
    price: 120,
    image: "/menu/cappuccino.jpg",
    rating: 4.9,
    reviews: 310,
    tags: ["classic"],
    popular: true,
  },
  {
    id: "latte",
    name: "Латте",
    category: "coffee",
    desc: "Мягкий эспрессо с молоком и тонкой пенкой. Классика, которую пьют весь день.",
    volume: "300 мл",
    price: 140,
    image: "/menu/latte.jpg",
    rating: 4.8,
    reviews: 124,
    tags: ["classic"],
    popular: true,
  },
  {
    id: "flatwhite",
    name: "Флэт уайт",
    category: "coffee",
    desc: "Двойной эспрессо и бархатистое молоко. Меньше пены — больше кофе.",
    volume: "250 мл",
    price: 150,
    image: "/menu/flatwhite.jpg",
    rating: 4.8,
    reviews: 97,
    tags: ["signature"],
  },
  {
    id: "raf",
    name: "Раф ванильный",
    category: "coffee",
    desc: "Сливки, ваниль и эспрессо, взбитые вместе. Сладкий, но не приторный.",
    volume: "300 мл",
    price: 160,
    image: "/menu/raf.jpg",
    rating: 4.9,
    reviews: 188,
    tags: ["signature"],
    popular: true,
  },
  {
    id: "iced",
    name: "Айс латте",
    category: "coffee",
    desc: "Холодное молоко, лёд и двойной шот. Для жары в Бишкеке и долгой прогулки.",
    volume: "350 мл",
    price: 170,
    image: "/menu/iced.jpg",
    rating: 4.7,
    reviews: 76,
    tags: ["cold"],
    popular: true,
  },
  {
    id: "matcha",
    name: "Матча латте",
    category: "coffee",
    desc: "Японская матча и тёплое молоко. Ровная, травяная, без горечи.",
    volume: "300 мл",
    price: 180,
    image: "/menu/matcha.jpg",
    rating: 4.6,
    reviews: 64,
    tags: ["signature"],
  },
  {
    id: "croissant",
    name: "Круассан",
    category: "bakery",
    desc: "Слоёное масло: хруст снаружи и тёплое тесто внутри. Печём утром.",
    volume: "1 шт",
    price: 90,
    image: "/menu/croissant.jpg",
    rating: 4.8,
    reviews: 151,
    tags: [],
    popular: true,
  },
  {
    id: "combo-morning",
    name: "Утренний набор",
    category: "combo",
    desc: "Американо и круассан в одном пакете. Дешевле, чем по отдельности.",
    volume: "напиток + выпечка",
    price: 180,
    image: "/menu/croissant.jpg",
    rating: 4.9,
    reviews: 54,
    tags: ["classic"],
  },
  {
    id: "combo-sweet",
    name: "Сладкая пауза",
    category: "combo",
    desc: "Ванильный раф и круассан. Когда хочется и кофе, и десерт.",
    volume: "напиток + выпечка",
    price: 220,
    image: "/menu/raf.jpg",
    rating: 4.8,
    reviews: 41,
    tags: ["signature"],
  },
];

export type Cafe = {
  id: string;
  name: string;
  address: string;
  hours: string;
  lat: number;
  lng: number;
  km: string;
};

export const CAFES: Cafe[] = [
  {
    id: "chuy",
    name: "Зерно на Чуй",
    address: "пр. Чуй, 114",
    hours: "07:00–23:00",
    lat: 42.8765,
    lng: 74.605,
    km: "1,2 км",
  },
  {
    id: "manas",
    name: "Зерно Азия Молл",
    address: "пр. Манаса, 55",
    hours: "10:00–22:00",
    lat: 42.8558,
    lng: 74.5842,
    km: "3,4 км",
  },
];

export const CAFE = CAFES[0];

export type Address = {
  id: string;
  label: string;
  text: string;
  lat: number;
  lng: number;
};

export const DEFAULT_ADDRESSES: Address[] = [
  { id: "home", label: "Дом", text: "ул. Манаса, 12, кв. 45", lat: 42.866, lng: 74.586 },
  { id: "office", label: "Офис", text: "ул. Киевская, 77", lat: 42.8751, lng: 74.5888 },
];

export const CITIES = ["Бишкек", "Ош", "Каракол"];

export const ETAS = ["Как можно скорее", "30–45 мин", "45–60 мин", "Через час"];

export const PAYMENTS = [
  { id: "card", name: "Картой онлайн" },
  { id: "cash", name: "Наличными курьеру" },
  { id: "phone", name: "Телефоном" },
] as const;

export type PaymentId = (typeof PAYMENTS)[number]["id"];

export const FAQ = [
  {
    q: "Сколько едет курьер?",
    a: "По Бишкеку обычно 20–40 минут. После оплаты на карте видно, где он сейчас.",
  },
  {
    q: "Можно без сиропа или льда?",
    a: "Да. Напишите в комментарии к заказу — бариста увидит до того, как начнёт готовить.",
  },
  {
    q: "Как работают баллы?",
    a: "5% с каждого заказа возвращаются баллами. На оплате можно списать до 30% чека. 500 баллов — капучино.",
  },
  {
    q: "Какие промокоды есть?",
    a: "ZERNO20 снимает 20% с корзины. SWEET50 снимает 50 с. Вводится в корзине.",
  },
];

export function productById(id: string) {
  return PRODUCTS.find((item) => item.id === id);
}

export function addonById(id: string) {
  return ADDONS.find((item) => item.id === id);
}

export function unitPrice(productId: string, addonIds: string[]) {
  const product = productById(productId);
  if (!product) return 0;
  const extra = addonIds.reduce((sum, id) => sum + (addonById(id)?.price ?? 0), 0);
  return product.price + extra;
}

export function productsFor(mode: CatalogMode) {
  return PRODUCTS.filter((item) => {
    if (mode === "all") return true;
    if (mode === "popular") return Boolean(item.popular);
    if (mode === "coffee") return item.category === "coffee";
    if (mode === "bakery") return item.category === "bakery";
    if (mode === "combo") return item.category === "combo";
    if (mode === "cold") return item.tags.includes("cold");
    if (mode === "signature") return item.tags.includes("signature");
    if (mode === "classic") return item.tags.includes("classic");
    return true;
  });
}

export function promoDiscount(code: string | null, subtotal: number) {
  if (!code || subtotal <= 0) return 0;
  if (code === "ZERNO20") return Math.round(subtotal * 0.2);
  if (code === "SWEET50") return Math.min(50, subtotal);
  return 0;
}

export function som(value: number) {
  return `${Math.round(value)} с`;
}

export function itemsLabel(count: number) {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) return `${count} товар`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${count} товара`;
  return `${count} товаров`;
}

export function clock(ts: number) {
  return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(ts);
}

export function dayTime(ts: number) {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(ts);
}
