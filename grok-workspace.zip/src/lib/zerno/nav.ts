import { create } from "zustand";
import type { CatalogMode } from "@/lib/zerno/data";

export type Screen =
  | { kind: "splash" }
  | { kind: "home" }
  | { kind: "catalog"; mode: CatalogMode; title: string }
  | { kind: "product"; productId: string }
  | { kind: "cart" }
  | { kind: "checkout" }
  | { kind: "search" }
  | { kind: "order"; orderId: string }
  | { kind: "map"; orderId: string | null }
  | { kind: "profile" }
  | { kind: "orders" }
  | { kind: "favorites" }
  | { kind: "promos" }
  | { kind: "notifications" }
  | { kind: "support" }
  | { kind: "addresses" }
  | { kind: "payments" };

type UiState = {
  stack: Screen[];
  toast: string | null;
  push: (screen: Screen) => void;
  back: () => void;
  reset: (screen: Screen) => void;
  showToast: (text: string) => void;
};

let toastTimer = 0;

export const useUi = create<UiState>((set, get) => ({
  stack: [{ kind: "splash" }],
  toast: null,
  push: (screen) => set({ stack: [...get().stack, screen] }),
  back: () => {
    const stack = get().stack;
    if (stack.length < 2) return;
    set({ stack: stack.slice(0, -1) });
  },
  reset: (screen) => set({ stack: [screen] }),
  showToast: (text) => {
    set({ toast: text });
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => set({ toast: null }), 2200);
  },
}));

export const useClock = create<{ now: number }>(() => ({ now: Date.now() }));

export function useScreen() {
  return useUi((state) => state.stack[state.stack.length - 1] ?? { kind: "home" as const });
}

export function screenKey(screen: Screen) {
  if (screen.kind === "product") return `product-${screen.productId}`;
  if (screen.kind === "catalog") return `catalog-${screen.mode}`;
  if (screen.kind === "order") return `order-${screen.orderId}`;
  if (screen.kind === "map") return `map-${screen.orderId ?? "cafes"}`;
  return screen.kind;
}
