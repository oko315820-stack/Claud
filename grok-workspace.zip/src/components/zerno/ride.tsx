import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Bike, Check, LocateFixed, MapPin, MessageCircle, Minus, Phone, Plus, Search } from "lucide-react";
import { CAFE, CAFES, clock, dayTime, som } from "@/lib/zerno/data";
import { useClock, useUi } from "@/lib/zerno/nav";
import { courierPoint, etaLeft, useApp, type Order, type OrderStatus } from "@/lib/zerno/store";
import { BackBar, Photo, PrimaryButton, Sheet, Stars } from "@/components/zerno/parts";

const STEPS: { id: OrderStatus; label: string }[] = [
  { id: "accepted", label: "Заказ принят" },
  { id: "cooking", label: "Готовится" },
  { id: "enroute", label: "В пути" },
  { id: "delivered", label: "Доставлен" },
];

function lonTile(lon: number, zoom: number) {
  return ((lon + 180) / 360) * 2 ** zoom;
}

function latTile(lat: number, zoom: number) {
  const rad = (lat * Math.PI) / 180;
  return ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * 2 ** zoom;
}

function MapCanvas({
  center,
  zoom,
  pins,
}: {
  center: { lat: number; lng: number };
  zoom: number;
  pins: { id: string; lat: number; lng: number; node: ReactNode }[];
}) {
  const theme = useApp((state) => state.theme);
  const [size, setSize] = useState({ w: 360, h: 420 });
  const [box, setBox] = useState<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!box) return;
    const apply = () => setSize({ w: Math.max(1, box.clientWidth), h: Math.max(1, box.clientHeight) });
    apply();
    const observer = new ResizeObserver(apply);
    observer.observe(box);
    return () => observer.disconnect();
  }, [box]);

  const tiles = useMemo(() => {
    const cx = lonTile(center.lng, zoom);
    const cy = latTile(center.lat, zoom);
    const tilesX = Math.max(2, Math.ceil(size.w / 256) + 2);
    const tilesY = Math.max(2, Math.ceil(size.h / 256) + 2);
    const left = Math.floor(cx - tilesX / 2);
    const top = Math.floor(cy - tilesY / 2);
    const originX = size.w / 2 - (cx - left) * 256;
    const originY = size.h / 2 - (cy - top) * 256;
    const max = 2 ** zoom;
    const list: { key: string; src: string; left: number; top: number }[] = [];
    for (let ix = 0; ix < tilesX; ix += 1) {
      for (let iy = 0; iy < tilesY; iy += 1) {
        const x = left + ix;
        const y = top + iy;
        if (y < 0 || y >= max) continue;
        const wrapped = ((x % max) + max) % max;
        const src =
          theme === "dark"
            ? `https://${"abcd"[(wrapped + y) % 4]}.basemaps.cartocdn.com/dark_all/${zoom}/${wrapped}/${y}.png`
            : `https://${"abcd"[(wrapped + y) % 4]}.basemaps.cartocdn.com/rastertiles/voyager/${zoom}/${wrapped}/${y}.png`;
        list.push({ key: `${zoom}-${wrapped}-${y}`, src, left: originX + ix * 256, top: originY + iy * 256 });
      }
    }
    return { list, originX, originY, left, top };
  }, [center.lat, center.lng, zoom, size.w, size.h, theme]);

  const place = (lat: number, lng: number) => ({
    left: tiles.originX + (lonTile(lng, zoom) - tiles.left) * 256,
    top: tiles.originY + (latTile(lat, zoom) - tiles.top) * 256,
  });

  return (
    <div ref={setBox} className="relative h-full overflow-hidden bg-chip">
      {tiles.list.map((tile) => (
        <img key={tile.key} alt="" src={tile.src} className="pointer-events-none absolute size-64 max-w-none" style={{ left: tile.left, top: tile.top }} />
      ))}
      {pins.map((pin) => {
        const pos = place(pin.lat, pin.lng);
        return (
          <div key={pin.id} className="absolute" style={{ left: pos.left, top: pos.top }}>
            {pin.node}
          </div>
        );
      })}
      <p className="absolute bottom-1 left-2 rounded-full bg-surface px-2 py-0.5 text-xs text-muted">© OpenStreetMap · CARTO</p>
    </div>
  );
}

export function MapScreen({ orderId }: { orderId: string | null }) {
  const order = useApp((state) => state.orders.find((item) => item.id === orderId) ?? null);
  const addresses = useApp((state) => state.addresses);
  const now = useClock((state) => state.now);
  const showToast = useUi((state) => state.showToast);
  const push = useUi((state) => state.push);
  const [zoom, setZoom] = useState(13);
  const [query, setQuery] = useState("");
  const [focus, setFocus] = useState<{ lat: number; lng: number } | null>(null);
  const [me, setMe] = useState<{ lat: number; lng: number } | null>(null);

  const places = useMemo(
    () => [
      ...CAFES.map((cafe) => ({ id: cafe.id, title: cafe.name, text: cafe.address, lat: cafe.lat, lng: cafe.lng })),
      ...addresses.map((item) => ({ id: item.id, title: item.label, text: item.text, lat: item.lat, lng: item.lng })),
    ],
    [addresses],
  );
  const found = places.filter((place) => {
    const needle = query.trim().toLowerCase();
    if (!needle) return false;
    return place.title.toLowerCase().includes(needle) || place.text.toLowerCase().includes(needle);
  });

  const anchor = order ?? { lat: addresses[0]?.lat ?? CAFE.lat, lng: addresses[0]?.lng ?? CAFE.lng };
  const center = focus ?? { lat: (CAFE.lat + anchor.lat) / 2, lng: (CAFE.lng + anchor.lng) / 2 };
  const moving = order && order.mode === "delivery" && order.status !== "delivered" ? courierPoint(order, now) : null;

  const pins = [
    ...CAFES.map((cafe) => ({
      id: cafe.id,
      lat: cafe.lat,
      lng: cafe.lng,
      node: (
        <span className="flex -translate-x-1/2 -translate-y-full flex-col items-center">
          <span className="rounded-full bg-surface px-2 py-1 text-xs font-bold shadow">{cafe.name.replace("Зерно ", "")}</span>
          <span className="size-3 rounded-full bg-primary" />
        </span>
      ),
    })),
    {
      id: "drop",
      lat: anchor.lat,
      lng: anchor.lng,
      node: (
        <span className="grid size-9 -translate-x-1/2 -translate-y-full place-items-center rounded-full bg-fg text-bg">
          <MapPin className="size-4" />
        </span>
      ),
    },
  ];
  if (moving) {
    pins.push({
      id: "courier",
      lat: moving.lat,
      lng: moving.lng,
      node: (
        <span className="grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-primary-fg ring-4 ring-surface">
          <Bike className="size-5" />
        </span>
      ),
    });
  }
  if (me) {
    pins.push({
      id: "me",
      lat: me.lat,
      lng: me.lng,
      node: <span className="block size-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-success ring-4 ring-surface" />,
    });
  }

  return (
    <div className="flex h-full flex-col">
      <BackBar title="Карта" />
      <div className="px-4 pb-3">
        <label className="flex h-12 items-center gap-2 rounded-2xl bg-chip px-3">
          <Search className="size-4 text-muted" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Поиск адреса или кафе"
            className="h-full w-full bg-transparent text-sm outline-none"
          />
        </label>
      </div>
      {query.trim() ? (
        <ul className="app-scroll min-h-0 flex-1 overflow-y-auto px-4">
          {found.length === 0 ? <li className="py-6 text-sm text-muted">Ничего не нашли</li> : null}
          {found.map((place) => (
            <li key={place.id}>
              <button
                type="button"
                onClick={() => {
                  setFocus({ lat: place.lat, lng: place.lng });
                  setZoom(15);
                  setQuery("");
                }}
                className="flex h-14 w-full flex-col items-start justify-center border-b border-line text-left"
              >
                <span className="text-sm font-bold">{place.title}</span>
                <span className="text-xs text-muted">{place.text}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <div className="relative min-h-0 flex-1">
          <MapCanvas center={center} zoom={zoom} pins={pins} />
          <div className="absolute top-3 right-3 flex flex-col gap-2">
            <button type="button" aria-label="Ближе" onClick={() => setZoom((value) => Math.min(16, value + 1))} className="grid size-11 place-items-center rounded-full bg-surface shadow">
              <Plus className="size-5" />
            </button>
            <button type="button" aria-label="Дальше" onClick={() => setZoom((value) => Math.max(12, value - 1))} className="grid size-11 place-items-center rounded-full bg-surface shadow">
              <Minus className="size-5" />
            </button>
            <button
              type="button"
              aria-label="Моё место"
              onClick={() => {
                if (!navigator.geolocation) {
                  showToast("Геолокация недоступна");
                  return;
                }
                navigator.geolocation.getCurrentPosition(
                  (pos) => {
                    const lat = pos.coords.latitude;
                    const lng = pos.coords.longitude;
                    if (Math.abs(lat - CAFE.lat) > 0.6 || Math.abs(lng - CAFE.lng) > 0.6) {
                      showToast("Вы далеко от Бишкека — карта остаётся на заказе");
                      return;
                    }
                    setMe({ lat, lng });
                    setFocus({ lat, lng });
                    setZoom(15);
                  },
                  () => showToast("Не удалось получить геолокацию"),
                  { enableHighAccuracy: true, timeout: 8000 },
                );
              }}
              className="grid size-11 place-items-center rounded-full bg-surface shadow"
            >
              <LocateFixed className="size-5" />
            </button>
          </div>
        </div>
      )}
      <div className="shrink-0 border-t border-border bg-surface px-4 py-3">
        {order ? (
          <div className="flex items-center gap-3">
            <span className="grid size-12 place-items-center rounded-full bg-primary text-sm font-bold text-primary-fg">ТС</span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">{order.status === "delivered" ? "Заказ доставлен" : "Тимур уже на смене"}</p>
              <p className="text-sm text-muted">{etaLeft(order, now)}</p>
            </div>
            <button type="button" onClick={() => push({ kind: "order", orderId: order.id })} className="text-sm font-bold text-primary">
              Заказ
            </button>
          </div>
        ) : (
          <div>
            <p className="text-sm font-bold">Две кофейни в городе</p>
            <p className="text-sm text-muted">Оформите заказ — курьер поедет от Чуй.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export function OrderView({ id }: { id: string }) {
  const order = useApp((state) => state.orders.find((item) => item.id === id));
  const chat = useApp((state) => state.courierChat);
  const sendCourier = useApp((state) => state.sendCourier);
  const repeatOrder = useApp((state) => state.repeatOrder);
  const now = useClock((state) => state.now);
  const back = useUi((state) => state.back);
  const stack = useUi((state) => state.stack);
  const reset = useUi((state) => state.reset);
  const push = useUi((state) => state.push);
  const showToast = useUi((state) => state.showToast);
  const [openChat, setOpenChat] = useState(false);
  const [text, setText] = useState("");
  if (!order) {
    return (
      <div className="p-6">
        <p>Заказ не найден.</p>
        <button type="button" className="mt-3 font-semibold text-primary" onClick={() => reset({ kind: "home" })}>
          На главную
        </button>
      </div>
    );
  }
  const leave = () => {
    if (stack.length < 2) reset({ kind: "home" });
    else back();
  };
  const currentIndex = STEPS.findIndex((step) => step.id === order.status);
  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 shrink-0 items-center gap-1 px-1">
        <button type="button" aria-label="Назад" onClick={leave} className="grid size-11 place-items-center rounded-full text-lg">
          ←
        </button>
        <h1 className="text-lg font-bold">Заказ #{order.id}</h1>
      </header>
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <article className="rounded-3xl bg-surface p-4 ring-1 ring-border">
          <div className="flex items-center gap-3">
            <span className="grid size-14 place-items-center rounded-full bg-primary text-lg font-bold text-primary-fg">ТС</span>
            <div className="min-w-0 flex-1">
              <p className="font-bold">Тимур Садыков</p>
              <p className="flex items-center gap-2 text-sm text-muted">
                <Stars value={4.9} />
                <span>256 заказов</span>
              </p>
              <p className="text-sm text-muted">Toyota Corolla · 01 KG 452</p>
            </div>
          </div>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={() => showToast("Звоним Тимуру Садыкову…")}
              className="grid size-11 flex-1 place-items-center rounded-2xl bg-primary-soft text-primary"
              aria-label="Позвонить курьеру"
            >
              <Phone className="size-5" />
            </button>
            <button
              type="button"
              onClick={() => setOpenChat(true)}
              className="grid size-11 flex-1 place-items-center rounded-2xl bg-chip"
              aria-label="Написать курьеру"
            >
              <MessageCircle className="size-5" />
            </button>
          </div>
        </article>

        <ol className="mt-4 flex flex-col gap-0 px-1">
          {STEPS.map((step, index) => {
            const hit = order.history.find((item) => item.status === step.id);
            const done = index < currentIndex;
            const current = index === currentIndex;
            return (
              <li key={step.id} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <span
                    className={
                      done
                        ? "grid size-6 place-items-center rounded-full bg-success text-cream"
                        : current
                          ? "grid size-6 place-items-center rounded-full bg-primary text-primary-fg"
                          : "grid size-6 place-items-center rounded-full bg-chip text-muted"
                    }
                  >
                    {done ? <Check className="size-3.5" /> : <span className="size-2 rounded-full bg-current" />}
                  </span>
                  {index < STEPS.length - 1 ? <span className="w-px flex-1 bg-line" /> : null}
                </div>
                <div className="flex min-h-12 flex-1 items-start justify-between pb-3">
                  <p className={current ? "font-bold" : "font-semibold"}>{step.label}</p>
                  <p className="text-sm text-muted">{hit ? clock(hit.at) : ""}</p>
                </div>
              </li>
            );
          })}
        </ol>

        {order.status === "enroute" ? (
          <p className="rounded-2xl bg-success-soft px-3 py-3 text-sm text-success">
            Курьер уже в пути. Ориентир — {etaLeft(order, now)}.
          </p>
        ) : null}

        <div className="mt-4">
          <PrimaryButton onClick={() => push({ kind: "map", orderId: order.id })}>Открыть карту</PrimaryButton>
        </div>

        <h2 className="mt-5 mb-2 font-bold">Состав</h2>
        <ul className="flex flex-col gap-2">
          {order.lines.map((line) => (
            <li key={`${line.productId}-${line.name}`} className="flex items-center gap-3">
              <Photo src={line.image} alt="" className="size-12 rounded-xl" />
              <span className="min-w-0 flex-1 text-sm font-semibold">
                {line.name} × {line.qty}
              </span>
              <span className="text-sm font-bold">{som(line.unit * line.qty)}</span>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted">{order.address}</p>
        <p className="text-sm text-muted">
          {order.payment} · {order.eta}
        </p>
        {order.comment ? <p className="mt-1 text-sm">Комментарий: {order.comment}</p> : null}
        <div className="mt-3 flex items-center justify-between">
          <span className="text-muted">Итого</span>
          <span className="text-xl font-bold">{som(order.total)}</span>
        </div>
        <button
          type="button"
          onClick={() => {
            repeatOrder(order.id);
            showToast("Состав снова в корзине");
            push({ kind: "cart" });
          }}
          className="mt-4 h-12 w-full rounded-full bg-chip text-sm font-bold"
        >
          Повторить заказ
        </button>
      </div>
      {openChat ? (
        <Sheet title="Тимур" onClose={() => setOpenChat(false)}>
          <Thread
            items={chat}
            mineLabel="Вы"
            themLabel="Тимур"
            value={text}
            onChange={setText}
            onSend={() => {
              sendCourier(text);
              setText("");
            }}
          />
        </Sheet>
      ) : null}
    </div>
  );
}

export function OrdersScreen() {
  const orders = useApp((state) => state.orders);
  const push = useUi((state) => state.push);
  const [filter, setFilter] = useState<"all" | "delivery" | "pickup">("all");
  const list = orders.filter((order) => filter === "all" || order.mode === filter);
  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 items-center px-4">
        <h1 className="text-lg font-bold">Мои заказы</h1>
      </header>
      <div className="flex gap-2 px-4 pb-3">
        {(
          [
            ["all", "Все"],
            ["delivery", "Доставки"],
            ["pickup", "Самовывоз"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={
              filter === id
                ? "h-9 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg"
                : "h-9 rounded-full bg-chip px-4 text-sm font-semibold"
            }
          >
            {label}
          </button>
        ))}
      </div>
      <div className="app-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        {list.length === 0 ? <p className="py-8 text-center text-sm text-muted">Таких заказов пока нет.</p> : null}
        <ul className="flex flex-col gap-3">
          {list.map((order) => (
            <OrderCard key={order.id} order={order} onOpen={() => push({ kind: "order", orderId: order.id })} />
          ))}
        </ul>
      </div>
    </div>
  );
}

function OrderCard({ order, onOpen }: { order: Order; onOpen: () => void }) {
  const label =
    order.status === "delivered" ? "Доставлен" : order.status === "enroute" ? "В пути" : order.status === "cooking" ? "Готовится" : "Принят";
  return (
    <li>
      <button type="button" onClick={onOpen} className="w-full rounded-3xl bg-surface p-3 text-left ring-1 ring-border">
        <span className="flex items-center justify-between gap-2">
          <span className={order.status === "delivered" ? "text-sm font-bold text-success" : "text-sm font-bold text-primary"}>
            {label}
          </span>
          <span className="text-xs text-muted">{dayTime(order.createdAt)}</span>
        </span>
        <span className="mt-1 block text-xs text-muted">#{order.id}</span>
        <span className="mt-2 flex items-center gap-2">
          <span className="flex min-w-0 flex-1 gap-1">
            {order.lines.slice(0, 3).map((line) => (
              <Photo key={line.productId + line.name} src={line.image} alt="" className="size-12 rounded-xl" />
            ))}
          </span>
          <span className="font-bold">{som(order.total)}</span>
        </span>
      </button>
    </li>
  );
}

function Thread({
  items,
  themLabel,
  value,
  onChange,
  onSend,
}: {
  items: { id: string; from: "me" | "them"; text: string }[];
  mineLabel: string;
  themLabel: string;
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
}) {
  return (
    <div>
      <div className="flex max-h-64 flex-col gap-2 overflow-y-auto">
        {items.length === 0 ? <p className="text-sm text-muted">Напишите {themLabel.toLowerCase()} — ответ придёт сразу.</p> : null}
        {items.map((item) => (
          <p
            key={item.id}
            className={
              item.from === "me"
                ? "ml-8 rounded-2xl bg-primary px-3 py-2 text-sm text-primary-fg"
                : "mr-8 rounded-2xl bg-chip px-3 py-2 text-sm"
            }
          >
            {item.text}
          </p>
        ))}
      </div>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          onSend();
        }}
      >
        <input
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder="Сообщение"
          className="h-12 min-w-0 flex-1 rounded-2xl bg-chip px-3 text-sm outline-none"
        />
        <button type="submit" className="h-12 rounded-2xl bg-primary px-4 text-sm font-bold text-primary-fg">
          Ок
        </button>
      </form>
    </div>
  );
}

export { Thread };
