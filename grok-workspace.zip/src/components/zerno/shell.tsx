import { useEffect, useState } from "react";
import type { Screen } from "@/lib/zerno/nav";
import { screenKey, useClock, useScreen, useUi } from "@/lib/zerno/nav";
import { useApp } from "@/lib/zerno/store";
import { FrameContext, showsTabs, TabBar } from "@/components/zerno/parts";
import { CartScreen, Catalog, Checkout, Home, ProductView, SearchScreen, Splash } from "@/components/zerno/shop";
import { MapScreen, OrdersScreen, OrderView } from "@/components/zerno/ride";
import {
  AddressesScreen,
  FavoritesScreen,
  NotesScreen,
  PaymentsScreen,
  ProfileScreen,
  PromosScreen,
  SupportScreen,
} from "@/components/zerno/account";

function View({ screen }: { screen: Screen }) {
  switch (screen.kind) {
    case "splash":
      return <Splash />;
    case "home":
      return <Home />;
    case "catalog":
      return <Catalog mode={screen.mode} title={screen.title} />;
    case "product":
      return <ProductView id={screen.productId} />;
    case "cart":
      return <CartScreen />;
    case "checkout":
      return <Checkout />;
    case "search":
      return <SearchScreen />;
    case "order":
      return <OrderView id={screen.orderId} />;
    case "map":
      return <MapScreen orderId={screen.orderId} />;
    case "profile":
      return <ProfileScreen />;
    case "orders":
      return <OrdersScreen />;
    case "favorites":
      return <FavoritesScreen />;
    case "promos":
      return <PromosScreen />;
    case "notifications":
      return <NotesScreen />;
    case "support":
      return <SupportScreen />;
    case "addresses":
      return <AddressesScreen />;
    case "payments":
      return <PaymentsScreen />;
    default:
      return <Home />;
  }
}

export function ZernoApp() {
  const screen = useScreen();
  const theme = useApp((state) => state.theme);
  const toast = useUi((state) => state.toast);
  const [frame, setFrame] = useState<HTMLDivElement | null>(null);

  useEffect(() => {
    const pending = useApp.persist.rehydrate();
    void Promise.resolve(pending).finally(() => {
      const next = useApp.getState().theme;
      document.documentElement.classList.toggle("dark", next === "dark");
      document.documentElement.style.colorScheme = next;
      const top = useUi.getState().stack.at(-1);
      if (useApp.getState().entered && top?.kind === "splash") {
        useUi.getState().reset({ kind: "home" });
      }
    });
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    document.documentElement.style.colorScheme = theme;
  }, [theme]);

  useEffect(() => {
    const id = window.setInterval(() => {
      const now = Date.now();
      useClock.setState({ now });
      useApp.getState().advanceOrders(now);
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="flex h-dvh items-center justify-center overflow-hidden bg-canvas">
      <FrameContext.Provider value={frame}>
        <div ref={setFrame} className="app-frame relative flex flex-col overflow-hidden bg-bg md:ring-1 md:ring-border">
          <div key={screenKey(screen)} className="screen-in min-h-0 flex-1 overflow-hidden">
            <View screen={screen} />
          </div>
          {showsTabs(screen.kind) ? <TabBar /> : null}
          {toast ? (
            <p role="status" className="pointer-events-none absolute inset-x-4 top-3 z-50 rounded-full bg-ink px-4 py-2 text-center text-sm font-semibold text-cream">
              {toast}
            </p>
          ) : null}
        </div>
      </FrameContext.Provider>
    </div>
  );
}
